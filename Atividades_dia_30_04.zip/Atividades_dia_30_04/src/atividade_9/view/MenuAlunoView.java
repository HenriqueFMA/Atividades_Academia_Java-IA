package atividade_9.view;

import atividade_9.controller.GerenciadorAlunoController;
import atividade_9.model.Aluno;
import java.util.Scanner;
import java.util.List;

public class MenuAlunoView {
    private GerenciadorAlunoController controller;
    private Scanner scanner;

    public MenuAlunoView(GerenciadorAlunoController controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    public void iniciar() {
        try {
            int opcao = -1;
            while (opcao != 0) {
                try {
                    exibirMenu();
                    opcao = lerInteiro();
                    procesarOpcao(opcao);
                } catch (NumberFormatException e) {
                    System.err.println("❌ Erro: Digite um número válido!");
                } catch (Exception e) {
                    System.err.println("❌ Erro: " + e.getMessage());
                }
            }
            System.out.println("\n✓ Programa encerrado com sucesso!");
        } catch (Exception e) {
            System.err.println("Erro fatal no menu: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    private void exibirMenu() {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("║        GERENCIADOR DE NOTAS DE ALUNOS                ║");
        System.out.println("╠══════════════════════════════════════════════════════╣");
        System.out.println("║  1. Adicionar Aluno                                  ║");
        System.out.println("║  2. Adicionar Nota a um Aluno                        ║");
        System.out.println("║  3. Listar Relatório Individual                      ║");
        System.out.println("║  4. Listar Estatísticas da Turma                     ║");
        System.out.println("║  5. Listar Distribuição de Resultados                ║");
        System.out.println("║  6. Listar Melhor(es) Aluno(s)                       ║");
        System.out.println("║  0. Sair                                             ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.print("Digite a opção: ");
    }

    private void procesarOpcao(int opcao) throws Exception {
        switch (opcao) {
            case 1 -> adicionarAluno();
            case 2 -> adicionarNota();
            case 3 -> controller.listarRelatorioIndividual();
            case 4 -> controller.listarEstatisticasTurma();
            case 5 -> controller.listarDistribuicaoResultados();
            case 6 -> controller.listarMelhorAluno();
            case 0 -> {
            }
            default -> System.out.println("❌ Opção inválida!");
        }
    }

    private void adicionarAluno() {
        try {
            System.out.print("Digite o nome do aluno (mínimo 3 caracteres): ");
            String nome = scanner.nextLine();
            controller.adicionarAluno(nome);
            System.out.println("✓ Aluno adicionado com sucesso!");
        } catch (IllegalArgumentException e) {
            System.err.println("❌ Erro ao adicionar aluno: " + e.getMessage());
        }
    }

    private void adicionarNota() {
        try {
            List<Aluno> alunos = controller.obterAlunos();

            if (alunos.isEmpty()) {
                System.out.println("❌ Nenhum aluno cadastrado!");
                return;
            }

            System.out.println("\nAlunos cadastrados:");
            for (int i = 0; i < alunos.size(); i++) {
                System.out.println((i + 1) + ". " + alunos.get(i).getNome());
            }

            System.out.print("Escolha o número do aluno: ");
            int indicAluno = lerInteiro() - 1;

            if (indicAluno < 0 || indicAluno >= alunos.size()) {
                System.out.println("❌ Índice de aluno inválido!");
                return;
            }

            System.out.println("Qual nota deseja adicionar? (1ª, 2ª ou 3ª)");
            System.out.print("Digite 1, 2 ou 3: ");
            int indicNota = lerInteiro() - 1;

            if (indicNota < 0 || indicNota > 2) {
                System.out.println("❌ Índice de nota inválido!");
                return;
            }

            System.out.print("Digite a nota (0-100): ");
            double nota = lerDouble();

            controller.adicionarNota(indicAluno, indicNota, nota);
            System.out.println("✓ Nota adicionada com sucesso!");
        } catch (NumberFormatException e) {
            System.err.println("❌ Erro: Digite um valor numérico válido!");
        } catch (Exception e) {
            System.err.println("❌ Erro: " + e.getMessage());
        }
    }

    private int lerInteiro() throws NumberFormatException {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw e;
        }
    }

    private double lerDouble() throws NumberFormatException {
        try {
            return Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw e;
        }
    }
}
