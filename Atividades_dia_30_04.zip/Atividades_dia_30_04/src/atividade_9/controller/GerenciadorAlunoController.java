package atividade_9.controller;

import atividade_9.model.Aluno;
import atividade_9.model.Turma;
import java.util.List;

public class GerenciadorAlunoController {
    private Turma turma;

    public GerenciadorAlunoController() {
        this.turma = new Turma();
    }

    public void adicionarAluno(String nome) throws IllegalArgumentException {
        try {
            Aluno aluno = new Aluno(nome);
            turma.adicionarAluno(aluno);
        } catch (IllegalArgumentException e) {
            throw e;
        }
    }

    public void adicionarNota(int indicAluno, int indicNota, double valor) throws Exception {
        try {
            if (indicAluno < 0 || indicAluno >= turma.totalAlunos()) {
                throw new IllegalArgumentException("Índice de aluno inválido");
            }
            Aluno aluno = turma.obterAlunos().get(indicAluno);
            aluno.adicionarNota(indicNota, valor);
        } catch (Exception e) {
            throw e;
        }
    }

    public List<Aluno> obterAlunos() {
        return turma.obterAlunos();
    }

    public double obterMediaAluno(int indicAluno) throws IndexOutOfBoundsException {
        try {
            if (indicAluno < 0 || indicAluno >= turma.totalAlunos()) {
                throw new IndexOutOfBoundsException("Índice de aluno inválido");
            }
            return turma.obterAlunos().get(indicAluno).calcularMedia();
        } catch (IndexOutOfBoundsException e) {
            throw e;
        }
    }

    public String obterSituacaoAluno(int indicAluno) throws IndexOutOfBoundsException {
        try {
            if (indicAluno < 0 || indicAluno >= turma.totalAlunos()) {
                throw new IndexOutOfBoundsException("Índice de aluno inválido");
            }
            return turma.obterAlunos().get(indicAluno).obterSituacao();
        } catch (IndexOutOfBoundsException e) {
            throw e;
        }
    }

    public Turma obterTurma() {
        return turma;
    }

    public void listarRelatorioIndividual() throws Exception {
        try {
            if (turma.totalAlunos() == 0) {
                throw new IllegalStateException("Nenhum aluno cadastrado");
            }
            System.out.println("\n╔══════════════════════════════════════════════════════╗");
            System.out.println("║         RELATÓRIO INDIVIDUAL DOS ALUNOS              ║");
            System.out.println("╚══════════════════════════════════════════════════════╝");

            for (Aluno aluno : turma.obterAlunos()) {
                System.out.println("\nAluno: " + aluno.getNome());
                System.out.println("Notas: " + aluno.getNotas()[0] + ", " + aluno.getNotas()[1] + ", " + aluno.getNotas()[2]);
                System.out.println("Média: " + String.format("%.2f", aluno.calcularMedia()));
                System.out.println("Status: " + aluno.obterSituacao());
            }
        } catch (Exception e) {
            System.err.println("Erro ao listar relatório individual: " + e.getMessage());
            throw e;
        }
    }

    public void listarEstatisticasTurma() throws Exception {
        try {
            if (turma.totalAlunos() == 0) {
                throw new IllegalStateException("Nenhum aluno cadastrado");
            }
            System.out.println("\n╔══════════════════════════════════════════════════════╗");
            System.out.println("║         ESTATÍSTICAS DA TURMA                        ║");
            System.out.println("╚══════════════════════════════════════════════════════╝");
            System.out.println("Quantidade de alunos: " + turma.totalAlunos());
            System.out.println("Maior média: " + String.format("%.2f", turma.maiorMediaTurma()));
            System.out.println("Menor média: " + String.format("%.2f", turma.menorMediaTurma()));
            System.out.println("Média geral da turma: " + String.format("%.2f", turma.mediaGeralTurma()));
        } catch (Exception e) {
            System.err.println("Erro ao listar estatísticas: " + e.getMessage());
            throw e;
        }
    }

    public void listarDistribuicaoResultados() throws Exception {
        try {
            if (turma.totalAlunos() == 0) {
                throw new IllegalStateException("Nenhum aluno cadastrado");
            }
            System.out.println("\n╔══════════════════════════════════════════════════════╗");
            System.out.println("║         DISTRIBUIÇÃO DE RESULTADOS                   ║");
            System.out.println("╚══════════════════════════════════════════════════════╝");
            System.out.println("Aprovados: " + turma.contarAprovados());
            System.out.println("Recuperação: " + turma.contarRecuperacao());
            System.out.println("Reprovados: " + turma.contarReprovados());
        } catch (Exception e) {
            System.err.println("Erro ao listar distribuição: " + e.getMessage());
            throw e;
        }
    }

    public void listarMelhorAluno() throws Exception {
        try {
            if (turma.totalAlunos() == 0) {
                throw new IllegalStateException("Nenhum aluno cadastrado");
            }
            System.out.println("\n╔══════════════════════════════════════════════════════╗");
            System.out.println("║         MELHOR(ES) ALUNO(S)                          ║");
            System.out.println("╚══════════════════════════════════════════════════════╝");
            List<Aluno> melhores = turma.obterAlunosMaiorMedia();
            for (Aluno aluno : melhores) {
                System.out.println("Nome: " + aluno.getNome());
                System.out.println("Média: " + String.format("%.2f", aluno.calcularMedia()));
            }
        } catch (Exception e) {
            System.err.println("Erro ao listar melhor aluno: " + e.getMessage());
            throw e;
        }
    }
}
