package atividade_9.model;

public class Aluno {
    private String nome;
    private double[] notas;
    private static final int TOTAL_NOTAS = 3;
    private static final int MIN_NOME_LENGTH = 3;
    private static final double MIN_NOTA = 0;
    private static final double MAX_NOTA = 100;

    public Aluno(String nome) throws IllegalArgumentException {
        try {
            if (nome == null || nome.trim().length() < MIN_NOME_LENGTH) {
                throw new IllegalArgumentException("Nome deve ter no mínimo 3 caracteres");
            }
            this.nome = nome.trim();
            this.notas = new double[TOTAL_NOTAS];
        } catch (IllegalArgumentException e) {
            throw e;
        }
    }

    public void adicionarNota(int indice, double nota) throws IllegalArgumentException {
        try {
            if (indice < 0 || indice >= TOTAL_NOTAS) {
                throw new IllegalArgumentException("Índice de nota inválido (0-2)");
            }
            if (nota < MIN_NOTA || nota > MAX_NOTA) {
                throw new IllegalArgumentException("Nota deve estar entre 0 e 100");
            }
            this.notas[indice] = nota;
        } catch (IllegalArgumentException e) {
            throw e;
        }
    }

    public double calcularMedia() {
        try {
            double soma = 0;
            for (double nota : notas) {
                soma += nota;
            }
            return soma / TOTAL_NOTAS;
        } catch (Exception e) {
            System.err.println("Erro ao calcular média: " + e.getMessage());
            return 0;
        }
    }

    public String obterSituacao() {
        try {
            double media = calcularMedia();
            return (media >= 70) ? "APROVADO" : (media >= 50 && media < 70) ? "RECUPERAÇÃO" : "REPROVADO";
        } catch (Exception e) {
            System.err.println("Erro ao obter situação: " + e.getMessage());
            return "ERRO";
        }
    }

    public String obterSituacaoDetalhada() {
        try {
            double media = calcularMedia();
            if (media >= 70) {
                return "≥ 70 - APROVADO";
            } else if (media >= 50 && media < 70) {
                return "≥ 50 e < 70 - RECUPERAÇÃO";
            } else {
                return "< 50 - REPROVADO";
            }
        } catch (Exception e) {
            System.err.println("Erro ao obter situação detalhada: " + e.getMessage());
            return "ERRO";
        }
    }

    public double[] getNotas() {
        return notas;
    }

    public String getNome() {
        return nome;
    }

    public double maiorNota() {
        try {
            double maior = notas[0];
            for (double nota : notas) {
                maior = nota > maior ? nota : maior;
            }
            return maior;
        } catch (Exception e) {
            System.err.println("Erro ao obter maior nota: " + e.getMessage());
            return 0;
        }
    }

    public double menorNota() {
        try {
            double menor = notas[0];
            for (double nota : notas) {
                menor = nota < menor ? nota : menor;
            }
            return menor;
        } catch (Exception e) {
            System.err.println("Erro ao obter menor nota: " + e.getMessage());
            return 0;
        }
    }
}
