package atividade_9.model;

import java.util.ArrayList;
import java.util.List;

public class Turma {
    private List<Aluno> alunos;

    public Turma() {
        this.alunos = new ArrayList<>();
    }

    public void adicionarAluno(Aluno aluno) throws IllegalArgumentException {
        try {
            if (aluno == null) {
                throw new IllegalArgumentException("Aluno não pode ser nulo");
            }
            this.alunos.add(aluno);
        } catch (IllegalArgumentException e) {
            throw e;
        }
    }

    public List<Aluno> obterAlunos() {
        return this.alunos;
    }

    public int totalAlunos() {
        try {
            return this.alunos.size();
        } catch (Exception e) {
            System.err.println("Erro ao obter total de alunos: " + e.getMessage());
            return 0;
        }
    }

    public double mediaGeralTurma() throws IllegalStateException {
        try {
            if (this.alunos.isEmpty()) {
                throw new IllegalStateException("Não há alunos na turma");
            }
            double somaMedia = 0;
            for (Aluno aluno : this.alunos) {
                somaMedia += aluno.calcularMedia();
            }
            return somaMedia / this.alunos.size();
        } catch (IllegalStateException e) {
            throw e;
        }
    }

    public double maiorMediaTurma() throws IllegalStateException {
        try {
            if (this.alunos.isEmpty()) {
                throw new IllegalStateException("Não há alunos na turma");
            }
            double maior = this.alunos.get(0).calcularMedia();
            for (Aluno aluno : this.alunos) {
                double media = aluno.calcularMedia();
                maior = media > maior ? media : maior;
            }
            return maior;
        } catch (IllegalStateException e) {
            throw e;
        }
    }

    public double menorMediaTurma() throws IllegalStateException {
        try {
            if (this.alunos.isEmpty()) {
                throw new IllegalStateException("Não há alunos na turma");
            }
            double menor = this.alunos.get(0).calcularMedia();
            for (Aluno aluno : this.alunos) {
                double media = aluno.calcularMedia();
                menor = media < menor ? media : menor;
            }
            return menor;
        } catch (IllegalStateException e) {
            throw e;
        }
    }

    public int contarAprovados() {
        try {
            int count = 0;
            for (Aluno aluno : this.alunos) {
                count += aluno.calcularMedia() >= 70 ? 1 : 0;
            }
            return count;
        } catch (Exception e) {
            System.err.println("Erro ao contar aprovados: " + e.getMessage());
            return 0;
        }
    }

    public int contarRecuperacao() {
        try {
            int count = 0;
            for (Aluno aluno : this.alunos) {
                double media = aluno.calcularMedia();
                count += (media >= 50 && media < 70) ? 1 : 0;
            }
            return count;
        } catch (Exception e) {
            System.err.println("Erro ao contar em recuperação: " + e.getMessage());
            return 0;
        }
    }

    public int contarReprovados() {
        try {
            int count = 0;
            for (Aluno aluno : this.alunos) {
                count += aluno.calcularMedia() < 50 ? 1 : 0;
            }
            return count;
        } catch (Exception e) {
            System.err.println("Erro ao contar reprovados: " + e.getMessage());
            return 0;
        }
    }

    public List<Aluno> obterAlunosMaiorMedia() {
        try {
            List<Aluno> resultado = new ArrayList<>();
            if (this.alunos.isEmpty()) {
                throw new IllegalStateException("Não há alunos na turma");
            }
            double maiorMedia = maiorMediaTurma();
            for (Aluno aluno : this.alunos) {
                if (aluno.calcularMedia() == maiorMedia) {
                    resultado.add(aluno);
                }
            }
            return resultado;
        } catch (Exception e) {
            System.err.println("Erro ao obter alunos com maior média: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
