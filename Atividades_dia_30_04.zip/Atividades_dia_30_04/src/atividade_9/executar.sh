

echo "╔════════════════════════════════════════════════════════╗"
echo "║     GERENCIADOR DE ALUNOS - ATIVIDADE 9               ║"
echo "║     Compilação e Execução                             ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$( cd "$SCRIPT_DIR/../.." && pwd )"
cd "$PROJECT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' 

print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${YELLOW}ℹ${NC} $1"
}

echo "Compilando projeto..."
echo "──────────────────────────────────────────────────────"

if javac -d bin src/atividade_9/**/*.java src/atividade_9/*.java 2>&1; then
    print_status "Compilação bem-sucedida!"
else
    print_error "Erro durante compilação!"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════╗"
echo "║           OPÇÕES DE EXECUÇÃO                          ║"
echo "╠════════════════════════════════════════════════════════╣"
echo "║  1. Executar Testes (Recomendado primeiro)            ║"
echo "║  2. Executar Programa Principal (Menu Interativo)     ║"
echo "║  3. Ambos (Testes + Programa)                        ║"
echo "║  0. Sair                                              ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""
read -p "Escolha uma opção [0-3]: " opcao

case $opcao in
    1)
        echo ""
        print_info "Executando Testes Unitários..."
        echo "──────────────────────────────────────────────────────"
        java -cp bin atividade_9.teste.TesteGerenciadorAluno
        ;;
    2)
        echo ""
        print_info "Executando Programa Principal..."
        echo "──────────────────────────────────────────────────────"
        java -cp bin atividade_9.PrincipalGerenciadorAlunos
        ;;
    3)
        echo ""
        print_info "Executando Testes Unitários..."
        echo "──────────────────────────────────────────────────────"
        java -cp bin atividade_9.teste.TesteGerenciadorAluno
        echo ""
        print_info "Executando Programa Principal..."
        echo "──────────────────────────────────────────────────────"
        java -cp bin atividade_9.PrincipalGerenciadorAlunos
        ;;
    0)
        print_info "Saindo..."
        exit 0
        ;;
    *)
        print_error "Opção inválida!"
        exit 1
        ;;
esac

echo ""
echo "╔════════════════════════════════════════════════════════╗"
echo "║           Execução Concluída                          ║"
echo "╚════════════════════════════════════════════════════════╝"
