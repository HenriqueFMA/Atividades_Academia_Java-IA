package atividade_9;

import atividade_9.controller.GerenciadorAlunoController;
import atividade_9.view.MenuAlunoView;

public class PrincipalGerenciadorAlunos {

    public static void main(String[] args) {
        try {
            GerenciadorAlunoController controller = new GerenciadorAlunoController();
            MenuAlunoView menu = new MenuAlunoView(controller);
            menu.iniciar();
        } catch (Exception e) {
            System.err.println("Erro fatal na aplicação: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
