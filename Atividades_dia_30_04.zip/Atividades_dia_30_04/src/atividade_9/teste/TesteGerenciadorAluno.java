package atividade_9.teste;

import atividade_9.controller.GerenciadorAlunoController;
import atividade_9.model.Aluno;
import atividade_9.model.Turma;

public class TesteGerenciadorAluno {

    private static int totalTestes = 0;
    private static int testesPassaram = 0;
    private static int testesFalharam = 0;

    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║         TESTES UNITÁRIOS - GERENCIADOR DE ALUNOS      ║");
        System.out.println("╚════════════════════════════════════════════════════════╝\n");

        testarCriacaoAluno();
        testarAdicionarNotas();
        testarCalculoMedia();
        testarSituacaoAluno();
        testarTurma();
        testarEstatisticasTurma();
        testarErros();

        exibirResumo();
    }

    private static void testarCriacaoAluno() {
        System.out.println("\n[TESTE] Criação de Aluno");
        System.out.println("─".repeat(54));

        teste("Criar aluno com nome válido", () -> {
            Aluno aluno = new Aluno("Maria");
            assert aluno.getNome().equals("Maria");
        });

        teste("Nome com menos de 3 caracteres deve lançar exceção", () -> {
            try {
                new Aluno("Ma");
                throw new AssertionError("Deveria ter lançado IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("mínimo 3 caracteres");
            }
        });

        teste("Nome null deve lançar exceção", () -> {
            try {
                new Aluno(null);
                throw new AssertionError("Deveria ter lançado IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("mínimo 3 caracteres");
            }
        });
    }

    private static void testarAdicionarNotas() {
        System.out.println("\n[TESTE] Adição de Notas");
        System.out.println("─".repeat(54));

        teste("Adicionar três notas válidas", () -> {
            Aluno aluno = new Aluno("João");
            aluno.adicionarNota(0, 80);
            aluno.adicionarNota(1, 90);
            aluno.adicionarNota(2, 70);
            assert aluno.getNotas()[0] == 80;
            assert aluno.getNotas()[1] == 90;
            assert aluno.getNotas()[2] == 70;
        });

        teste("Nota > 100 deve lançar exceção", () -> {
            Aluno aluno = new Aluno("Pedro");
            try {
                aluno.adicionarNota(0, 150);
                throw new AssertionError("Deveria ter lançado IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("entre 0 e 100");
            }
        });

        teste("Nota negativa deve lançar exceção", () -> {
            Aluno aluno = new Aluno("Ana");
            try {
                aluno.adicionarNota(0, -10);
                throw new AssertionError("Deveria ter lançado IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("entre 0 e 100");
            }
        });

        teste("Índice inválido deve lançar exceção", () -> {
            Aluno aluno = new Aluno("Carlos");
            try {
                aluno.adicionarNota(5, 80);
                throw new AssertionError("Deveria ter lançado IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("inválido");
            }
        });
    }

    private static void testarCalculoMedia() {
        System.out.println("\n[TESTE] Cálculo de Média");
        System.out.println("─".repeat(54));

        teste("Calcular média de três notas", () -> {
            Aluno aluno = new Aluno("Lucas");
            aluno.adicionarNota(0, 70);
            aluno.adicionarNota(1, 80);
            aluno.adicionarNota(2, 90);
            double media = aluno.calcularMedia();
            assert Math.abs(media - 80.0) < 0.01;
        });

        teste("Calcular maior e menor nota", () -> {
            Aluno aluno = new Aluno("Sofia");
            aluno.adicionarNota(0, 50);
            aluno.adicionarNota(1, 100);
            aluno.adicionarNota(2, 75);
            assert aluno.maiorNota() == 100;
            assert aluno.menorNota() == 50;
        });
    }

    private static void testarSituacaoAluno() {
        System.out.println("\n[TESTE] Situação do Aluno");
        System.out.println("─".repeat(54));

        teste("Aluno com média 75 deve estar APROVADO", () -> {
            Aluno aluno = new Aluno("Rafael");
            aluno.adicionarNota(0, 70);
            aluno.adicionarNota(1, 80);
            aluno.adicionarNota(2, 75);
            assert aluno.obterSituacao().equals("APROVADO");
        });

        teste("Aluno com média 60 deve estar em RECUPERAÇÃO", () -> {
            Aluno aluno = new Aluno("Beatriz");
            aluno.adicionarNota(0, 50);
            aluno.adicionarNota(1, 65);
            aluno.adicionarNota(2, 65);
            assert aluno.obterSituacao().equals("RECUPERAÇÃO");
        });

        teste("Aluno com média 40 deve estar REPROVADO", () -> {
            Aluno aluno = new Aluno("Diego");
            aluno.adicionarNota(0, 30);
            aluno.adicionarNota(1, 40);
            aluno.adicionarNota(2, 50);
            assert aluno.obterSituacao().equals("REPROVADO");
        });
    }

    private static void testarTurma() {
        System.out.println("\n[TESTE] Turma");
        System.out.println("─".repeat(54));

        teste("Adicionar aluno à turma", () -> {
            Turma turma = new Turma();
            Aluno aluno = new Aluno("Fernanda");
            turma.adicionarAluno(aluno);
            assert turma.totalAlunos() == 1;
            assert turma.obterAlunos().get(0).getNome().equals("Fernanda");
        });

        teste("Adicionar múltiplos alunos", () -> {
            Turma turma = new Turma();
            turma.adicionarAluno(new Aluno("Aluno1"));
            turma.adicionarAluno(new Aluno("Aluno2"));
            turma.adicionarAluno(new Aluno("Aluno3"));
            assert turma.totalAlunos() == 3;
        });
    }

    private static void testarEstatisticasTurma() {
        System.out.println("\n[TESTE] Estatísticas da Turma");
        System.out.println("─".repeat(54));

        teste("Contar aprovados na turma", () -> {
            Turma turma = criarTurmaComAlunos();
            int aprovados = turma.contarAprovados();
            assert aprovados == 2;
        });

        teste("Contar alunos em recuperação", () -> {
            Turma turma = criarTurmaComAlunos();
            int recuperacao = turma.contarRecuperacao();
            assert recuperacao == 1;
        });

        teste("Contar reprovados na turma", () -> {
            Turma turma = criarTurmaComAlunos();
            int reprovados = turma.contarReprovados();
            assert reprovados == 1;
        });

        teste("Calcular média geral da turma", () -> {
            Turma turma = criarTurmaComAlunos();
            double mediaGeral = turma.mediaGeralTurma();
            assert mediaGeral > 0;
        });
    }

    private static void testarErros() {
        System.out.println("\n[TESTE] Tratamento de Erros");
        System.out.println("─".repeat(54));

        teste("Operação em turma vazia deve lançar exceção", () -> {
            Turma turma = new Turma();
            try {
                turma.mediaGeralTurma();
                throw new AssertionError("Deveria ter lançado exceção");
            } catch (Exception e) {
                assert e.getMessage().contains("Não há alunos");
            }
        });

        teste("Adicionar aluno null deve lançar exceção", () -> {
            Turma turma = new Turma();
            try {
                turma.adicionarAluno(null);
                throw new AssertionError("Deveria ter lançado exceção");
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("não pode ser nulo");
            }
        });
    }

    private static Turma criarTurmaComAlunos() throws Exception {
        Turma turma = new Turma();
        Aluno a1 = new Aluno("Aprovado1");
        a1.adicionarNota(0, 70);
        a1.adicionarNota(1, 80);
        a1.adicionarNota(2, 75);
        turma.adicionarAluno(a1);

        Aluno a2 = new Aluno("Aprovado2");
        a2.adicionarNota(0, 85);
        a2.adicionarNota(1, 88);
        a2.adicionarNota(2, 92);
        turma.adicionarAluno(a2);

        Aluno a3 = new Aluno("Recuperacao");
        a3.adicionarNota(0, 55);
        a3.adicionarNota(1, 60);
        a3.adicionarNota(2, 65);
        turma.adicionarAluno(a3);

        Aluno a4 = new Aluno("Reprovado");
        a4.adicionarNota(0, 30);
        a4.adicionarNota(1, 40);
        a4.adicionarNota(2, 35);
        turma.adicionarAluno(a4);

        return turma;
    }

    private static void teste(String descricao, TestExecutor executor) {
        totalTestes++;
        try {
            executor.executar();
            System.out.println("  ✓ " + descricao);
            testesPassaram++;
        } catch (Exception e) {
            System.out.println("  ✗ " + descricao);
            System.out.println("    └─ Erro: " + e.getMessage());
            testesFalharam++;
        }
    }

    private static void exibirResumo() {
        System.out.println("\n╔════════════════════════════════════════════════════════╗");
        System.out.println("║                    RESUMO DOS TESTES                   ║");
        System.out.println("╠════════════════════════════════════════════════════════╣");
        System.out.println("║  Total de testes: " + totalTestes);
        System.out.println("║  ✓ Passaram: " + testesPassaram);
        System.out.println("║  ✗ Falharam: " + testesFalharam);
        String status = testesFalharam == 0 ? "SUCESSO" : "COM FALHAS";
        System.out.println("║  Status: " + status);
        System.out.println("╚════════════════════════════════════════════════════════╝");
    }

    @FunctionalInterface
    interface TestExecutor {
        void executar() throws Exception;
    }
}
