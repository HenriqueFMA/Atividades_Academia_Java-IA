package atividade_9.teste;

import atividade_9.controller.GerenciadorAlunoController;
import atividade_9.model.Aluno;

public class DemostrativaAtividade9 {

    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║    DEMONSTRAÇÃO PRÁTICA - ATIVIDADE 9                 ║");
        System.out.println("║    Operadores Ternários + MVC + Try-Catch             ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");

        demonstradoraTernarios();
        demonstradoraMVC();
        demonstradoraErros();
        demonstradoraRelatorios();
    }

    private static void demonstradoraTernarios() {
        System.out.println("\n┌────────────────────────────────────────────────────┐");
        System.out.println("│ 1. OPERADORES TERNÁRIOS                             │");
        System.out.println("└────────────────────────────────────────────────────┘");

        try {
            System.out.println("\n[Exemplo 1] Avaliação de Situação");
            Aluno aluno1 = new Aluno("Maria");
            aluno1.adicionarNota(0, 85);
            aluno1.adicionarNota(1, 90);
            aluno1.adicionarNota(2, 80);

            double media = aluno1.calcularMedia();
            System.out.println("Nome: " + aluno1.getNome());
            System.out.println("Média: " + String.format("%.2f", media));

            String situacao = (media >= 70)
                ? "✅ APROVADO"
                : (media >= 50 && media < 70)
                    ? "🔄 RECUPERAÇÃO"
                    : "❌ REPROVADO";
            System.out.println("Situação: " + situacao);


            System.out.println("\n[Exemplo 2] Encontrar Maior Nota");
            double[] notas = aluno1.getNotas();
            double maior = notas[0];
            for (double nota : notas) {
                maior = nota > maior ? nota : maior;
            }
            System.out.println("Notas: " + notas[0] + ", " + notas[1] + ", " + notas[2]);
            System.out.println("Maior nota: " + maior);

        } catch (Exception e) {
            System.err.println("Erro na demonstração: " + e.getMessage());
        }
    }

    private static void demonstradoraMVC() {
        System.out.println("\n┌────────────────────────────────────────────────────┐");
        System.out.println("│ 2. ARQUITETURA MVC (Model-View-Controller)         │");
        System.out.println("└────────────────────────────────────────────────────┘");

        try {
            System.out.println("\n[Fluxo MVC]");
            System.out.println("1. CONTROLLER: GerenciadorAlunoController");
            System.out.println("   └─ Coordena operações entre Model e View");

            GerenciadorAlunoController controller = new GerenciadorAlunoController();

            System.out.println("\n2. MODEL: Aluno + Turma");
            System.out.println("   └─ Adicionar alunos e validar dados");
            controller.adicionarAluno("João");
            controller.adicionarAluno("Ana");
            controller.adicionarAluno("Pedro");

            System.out.println("\n3. ADDICIONANDO DADOS");
            controller.adicionarNota(0, 0, 70);
            controller.adicionarNota(0, 1, 80);
            controller.adicionarNota(0, 2, 75);

            controller.adicionarNota(1, 0, 90);
            controller.adicionarNota(1, 1, 85);
            controller.adicionarNota(1, 2, 95);

            controller.adicionarNota(2, 0, 40);
            controller.adicionarNota(2, 1, 45);
            controller.adicionarNota(2, 2, 50);

            System.out.println("   └─ 3 alunos com 3 notas cada");

            System.out.println("\n4. VIEW: Apresentação de Dados");
            System.out.println("   ┌─ Relatório Individual");
            for (int i = 0; i < controller.obterAlunos().size(); i++) {
                double media = controller.obterMediaAluno(i);
                String situacao = controller.obterSituacaoAluno(i);
                System.out.println("   │  " + controller.obterAlunos().get(i).getNome() +
                                 " → Média: " + String.format("%.2f", media) +
                                 " → " + situacao);
            }
            System.out.println("   └─");

        } catch (Exception e) {
            System.err.println("Erro na demonstração MVC: " + e.getMessage());
        }
    }

    private static void demonstradoraErros() {
        System.out.println("\n┌────────────────────────────────────────────────────┐");
        System.out.println("│ 3. TRATAMENTO DE ERROS COM TRY-CATCH               │");
        System.out.println("└────────────────────────────────────────────────────┘");

        System.out.println("\n[Teste 1] Nome com menos de 3 caracteres");
        try {
            new Aluno("AB");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Exceção capturada: " + e.getMessage());
        }

        System.out.println("\n[Teste 2] Nota fora do intervalo (> 100)");
        try {
            Aluno aluno = new Aluno("Test");
            aluno.adicionarNota(0, 150);
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Exceção capturada: " + e.getMessage());
        }

        System.out.println("\n[Teste 3] Índice de nota inválido");
        try {
            Aluno aluno = new Aluno("Test");
            aluno.adicionarNota(10, 80);
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Exceção capturada: " + e.getMessage());
        }

        System.out.println("\n[Teste 4] Aluno null na turma");
        try {
            Aluno aluno = new Aluno("Test");
            aluno.getNome();
            java.util.List<Aluno> alunos = new java.util.ArrayList<>();
            alunos.add(null);
            if (alunos.get(0) == null) {
                throw new IllegalArgumentException("Aluno não pode ser nulo");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Exceção capturada: " + e.getMessage());
        }
    }

    private static void demonstradoraRelatorios() {
        System.out.println("\n┌────────────────────────────────────────────────────┐");
        System.out.println("│ 4. GERANDO RELATÓRIOS COM DADOS                    │");
        System.out.println("└────────────────────────────────────────────────────┘");

        try {
            GerenciadorAlunoController controller = new GerenciadorAlunoController();

            controller.adicionarAluno("Alice");
            controller.adicionarAluno("Bob");
            controller.adicionarAluno("Carol");
            controller.adicionarAluno("David");

            double[][] notas = {
                {85, 90, 88},
                {75, 80, 70},
                {60, 55, 65},
                {40, 35, 45}
            };

            for (int i = 0; i < notas.length; i++) {
                for (int j = 0; j < 3; j++) {
                    controller.adicionarNota(i, j, notas[i][j]);
                }
            }

            System.out.println("\n[Resumo da Turma]");
            System.out.println("Total de alunos: " + controller.obterAlunos().size());
            System.out.println("Aprovados: " + controller.obterTurma().contarAprovados());
            System.out.println("Recuperação: " + controller.obterTurma().contarRecuperacao());
            System.out.println("Reprovados: " + controller.obterTurma().contarReprovados());
            System.out.println("Média Geral: " + String.format("%.2f", controller.obterTurma().mediaGeralTurma()));
            System.out.println("Maior Média: " + String.format("%.2f", controller.obterTurma().maiorMediaTurma()));
            System.out.println("Menor Média: " + String.format("%.2f", controller.obterTurma().menorMediaTurma()));

        } catch (Exception e) {
            System.err.println("Erro na demonstração de relatórios: " + e.getMessage());
        }
    }
}
