package atividade_8.controller;


import atividade_8.model.Cliente;
import atividade_8.model.ContaCorrente;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ContaCorrenteController {

    private final List<ContaCorrente> contas = new ArrayList<>();
    private int proximoNumero = 1001;

    public ContaCorrente criarConta(String nome, String sobrenome, String cpf, double saldoInicial) {
        try {
            if (cpfJaExiste(cpf)) {
                System.out.println("✘ Erro: Já existe um cliente com esse CPF cadastrado.");
                return null;
            }

            Cliente cliente = new Cliente(nome, sobrenome, cpf);
            ContaCorrente conta = new ContaCorrente(proximoNumero++, cliente, saldoInicial);
            contas.add(conta);
            return conta;
        } catch (IllegalArgumentException e) {
            System.out.println("✘ Erro: " + e.getMessage());
            return null;
        } catch (Exception e) {
            System.out.println("✘ Erro ao criar conta: " + e.getMessage());
            return null;
        }
    }

    private boolean cpfJaExiste(String cpf) {
        if (cpf == null) return false;
        String cpfLimpo = cpf.replaceAll("[^0-9]", "");
        return contas.stream()
                .anyMatch(c -> {
                    String cpfExistente = c.getCliente().getCpf();
                    return cpfExistente != null && cpfExistente.equals(cpfLimpo);
                });
    }

    public Optional<ContaCorrente> buscarPorNumero(int numero) {
        return contas.stream().filter(c -> c.getNumero() == numero).findFirst();
    }

    public String depositar(int numero, double valor) {
        return buscarPorNumero(numero).map(c -> {
            if (c.depositar(valor))
                return String.format("✔ Depósito de R$ %.2f realizado. Novo saldo: R$ %.2f", valor, c.getSaldo());
            return "✘ Valor inválido para depósito.";
        }).orElse("✘ Conta não encontrada.");
    }

    public String sacar(int numero, double valor) {
        return buscarPorNumero(numero).map(c -> {
            if (c.sacar(valor))
                return String.format("✔ Saque de R$ %.2f realizado. Novo saldo: R$ %.2f", valor, c.getSaldo());
            return "✘ Saldo insuficiente ou valor inválido.";
        }).orElse("✘ Conta não encontrada.");
    }

    public String transferir(int numOrigem, int numDestino, double valor) {
        Optional<ContaCorrente> origem = buscarPorNumero(numOrigem);
        Optional<ContaCorrente> destino = buscarPorNumero(numDestino);
        if (origem.isEmpty()) return "✘ Conta de origem não encontrada.";
        if (destino.isEmpty()) return "✘ Conta de destino não encontrada.";
        if (origem.get().transferir(destino.get(), valor))
            return String.format("✔ Transferência de R$ %.2f realizada para conta #%d.", valor, numDestino);
        return "✘ Saldo insuficiente — transferência cancelada.";
    }

    public String obterExtrato(int numero, boolean mostrarSaldo) {
        return buscarPorNumero(numero)
                .map(c -> c.gerarExtrato(mostrarSaldo))
                .orElse("✘ Conta não encontrada.");
    }

    public String obterSaldo(int numero) {
        return buscarPorNumero(numero)
                .map(c -> String.format("Saldo da conta #%d: R$ %.2f", c.getNumero(), c.getSaldo()))
                .orElse("✘ Conta não encontrada.");
    }

    public List<ContaCorrente> listarContas() {
        return new ArrayList<>(contas);
    }
}