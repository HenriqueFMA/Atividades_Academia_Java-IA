package atividade_8.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ContaCorrente {

    private final int numero;
    private final LocalDate data;
    private double saldo;
    private Cliente cliente;
    private final List<Transacao> extrato;

    public ContaCorrente(int numero, Cliente cliente, double saldoInicial) {
        this.numero = numero;
        this.cliente = cliente;
        this.saldo = saldoInicial;
        this.data = LocalDate.now();
        this.extrato = new ArrayList<>();

        try {
            if (saldoInicial < 0) {
                throw new IllegalArgumentException("Saldo inicial não pode ser negativo.");
            }

            if (saldoInicial > 0) {
                extrato.add(new Transacao(
                        Transacao.Tipo.DEPOSITO,
                        saldoInicial,
                        saldo,
                        "Saldo inicial"
                ));
            }

        } catch (Exception e) {
            System.out.println("Erro ao criar conta: " + e.getMessage());
        }
    }

    public boolean depositar(double valor) {
        try {
            if (valor <= 0) {
                throw new IllegalArgumentException("Valor de depósito inválido.");
            }

            saldo += valor;

            extrato.add(new Transacao(
                    Transacao.Tipo.DEPOSITO,
                    valor,
                    saldo,
                    "Depósito"
            ));

            return true;

        } catch (Exception e) {
            System.out.println("Erro ao depositar: " + e.getMessage());
            return false;
        }
    }

    public boolean sacar(double valor) {
        try {
            if (valor <= 0) {
                throw new IllegalArgumentException("Valor inválido.");
            }

            if (valor > saldo) {
                throw new IllegalStateException("Saldo insuficiente.");
            }

            saldo -= valor;

            extrato.add(new Transacao(
                    Transacao.Tipo.SAQUE,
                    valor,
                    saldo,
                    "Saque"
            ));

            return true;

        } catch (Exception e) {
            System.out.println("Erro ao sacar: " + e.getMessage());
            return false;
        }
    }

    public boolean transferir(ContaCorrente destino, double valor) {
        try {
            if (destino == null) {
                throw new NullPointerException("Conta destino não pode ser nula.");
            }

            if (valor <= 0) {
                throw new IllegalArgumentException("Valor inválido.");
            }

            if (saldo < valor) {
                throw new IllegalStateException("Saldo insuficiente.");
            }

            saldo -= valor;

            extrato.add(new Transacao(
                    Transacao.Tipo.TRANSFERENCIA_SAIDA,
                    valor,
                    saldo,
                    "Transf. para #" + destino.getNumero()
            ));

            destino.receberTransferencia(this, valor);

            return true;

        } catch (Exception e) {
            System.out.println("Erro na transferência: " + e.getMessage());
            return false;
        }
    }

    private void receberTransferencia(ContaCorrente origem, double valor) {
        try {
            if (origem == null) {
                throw new NullPointerException("Conta de origem inválida.");
            }

            if (valor <= 0) {
                throw new IllegalArgumentException("Valor inválido.");
            }

            saldo += valor;

            extrato.add(new Transacao(
                    Transacao.Tipo.TRANSFERENCIA_ENTRADA,
                    valor,
                    saldo,
                    "Transf. de #" + origem.getNumero()
            ));

        } catch (Exception e) {
            System.out.println("Erro ao receber transferência: " + e.getMessage());
        }
    }

    public String gerarExtrato(boolean mostrarSaldo) {
        try {
            StringBuilder sb = new StringBuilder();

            if (cliente == null) {
                throw new NullPointerException("Cliente não definido.");
            }

            sb.append("═".repeat(90)).append("\n");
            sb.append(String.format("  EXTRATO - Conta #%d | %s%n",
                    numero, cliente.getNomeCompleto()));
            sb.append("═".repeat(90)).append("\n");

            sb.append(String.format("%-28s | %-22s | %-14s | %s%n",
                    "Data/Hora", "Descrição", "Valor", "Saldo"));
            sb.append("─".repeat(90)).append("\n");

            double totalEntradas = 0, totalSaidas = 0;

            for (Transacao t : extrato) {

                boolean entrada =
                        t.getTipo() == Transacao.Tipo.DEPOSITO ||
                        t.getTipo() == Transacao.Tipo.TRANSFERENCIA_ENTRADA;

                if (entrada) totalEntradas += t.getValor();
                else totalSaidas += t.getValor();

                if (!mostrarSaldo) {
                    String sinal = entrada ? "+" : "-";

                    sb.append(String.format("%-28s | %-22s | %s R$%10.2f | Saldo: %-12s%n",
                            t.getDataHora().format(
                                    java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")),
                            t.getDescricao(),
                            sinal,
                            t.getValor(),
                            "****"
                    ));
                } else {
                    sb.append(t).append("\n");
                }
            }

            sb.append("─".repeat(90)).append("\n");
            sb.append(String.format("  Total Entradas : R$ %10.2f%n", totalEntradas));
            sb.append(String.format("  Total Saídas   : R$ %10.2f%n", totalSaidas));

            if (mostrarSaldo) {
                sb.append(String.format("  Saldo Final    : R$ %10.2f%n", saldo));
            } else {
                sb.append("  Saldo Final    : ****\n");
            }

            sb.append("═".repeat(90)).append("\n");

            return sb.toString();

        } catch (Exception e) {
            return "Erro ao gerar extrato: " + e.getMessage();
        }
    }

    public int getNumero() { return numero; }
    public LocalDate getData() { return data; }
    public double getSaldo() { return saldo; }
    public Cliente getCliente() { return cliente; }

    public void setCliente(Cliente cliente) {
        try {
            if (cliente == null) {
                throw new NullPointerException("Cliente não pode ser nulo.");
            }
            this.cliente = cliente;

        } catch (Exception e) {
            System.out.println("Erro ao definir cliente: " + e.getMessage());
        }
    }

    public List<Transacao> getExtrato() {
        return Collections.unmodifiableList(extrato);
    }
}