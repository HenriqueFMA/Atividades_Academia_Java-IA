package atividade_8.model;

public class Cliente {

    private String nome;
    private String sobrenome;
    private String cpf;

    public Cliente(String nome, String sobrenome, String cpf) throws IllegalArgumentException {
        this.nome = nome;
        this.sobrenome = sobrenome;
        setCpf(cpf);
    }

    public String getNome() { return nome; }

    public void setNome(String nome) {
        try {
            if (nome == null || nome.isBlank()) {
                throw new IllegalArgumentException("Nome inválido.");
            }
            this.nome = nome;
        } catch (Exception e) {
            System.out.println("Erro no nome: " + e.getMessage());
        }
    }

    public String getSobrenome() { return sobrenome; }

    public void setSobrenome(String sobrenome) {
        try {
            if (sobrenome == null || sobrenome.isBlank()) {
                throw new IllegalArgumentException("Sobrenome inválido.");
            }
            this.sobrenome = sobrenome;
        } catch (Exception e) {
            System.out.println("Erro no sobrenome: " + e.getMessage());
        }
    }

    public String getCpf() { return cpf; }

    public void setCpf(String cpf) throws IllegalArgumentException {
        if (!validarCpf(cpf)) {
            throw new IllegalArgumentException("CPF inválido.");
        }
        this.cpf = limparCpf(cpf);
    }

    public String getNomeCompleto() {
        return nome + " " + sobrenome;
    }

    @Override
    public String toString() {
        return String.format("Cliente: %s | CPF: %s", getNomeCompleto(), formatarCpf(cpf));
    }


    private String limparCpf(String cpf) {
        return cpf.replaceAll("[^0-9]", "");
    }

    private boolean validarCpf(String cpf) {
        if (cpf == null) return false;

        cpf = limparCpf(cpf);

        if (cpf.length() != 11) return false;


        if (cpf.matches("(\\d)\\1{10}")) return false;

        try {
            int soma = 0;
            for (int i = 0; i < 9; i++) {
                soma += (cpf.charAt(i) - '0') * (10 - i);
            }
            int dig1 = 11 - (soma % 11);
            dig1 = (dig1 >= 10) ? 0 : dig1;

            soma = 0;
            for (int i = 0; i < 10; i++) {
                soma += (cpf.charAt(i) - '0') * (11 - i);
            }
            int dig2 = 11 - (soma % 11);
            dig2 = (dig2 >= 10) ? 0 : dig2;

            return dig1 == (cpf.charAt(9) - '0') &&
                   dig2 == (cpf.charAt(10) - '0');

        } catch (Exception e) {
            return false;
        }
    }

    private String formatarCpf(String cpf) {
        if (cpf == null || cpf.length() != 11) return cpf;

        return cpf.substring(0, 3) + "." +
               cpf.substring(3, 6) + "." +
               cpf.substring(6, 9) + "-" +
               cpf.substring(9, 11);
    }
}