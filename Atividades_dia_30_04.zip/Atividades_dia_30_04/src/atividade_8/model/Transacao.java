package atividade_8.model;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transacao {

    public enum Tipo {
        DEPOSITO, SAQUE, TRANSFERENCIA_SAIDA, TRANSFERENCIA_ENTRADA
    }

    private final Tipo tipo;
    private final double valor;
    private final double saldoApos;
    private final LocalDateTime dataHora;
    private final String descricao;

    public Transacao(Tipo tipo, double valor, double saldoApos, String descricao) {
        this.tipo = tipo;
        this.valor = valor;
        this.saldoApos = saldoApos;
        this.descricao = descricao;
        this.dataHora = LocalDateTime.now();
    }

    public Tipo getTipo() { return tipo; }
    public double getValor() { return valor; }
    public double getSaldoApos() { return saldoApos; }
    public String getDescricao() { return descricao; }
    public LocalDateTime getDataHora() { return dataHora; }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String sinal = (tipo == Tipo.DEPOSITO || tipo == Tipo.TRANSFERENCIA_ENTRADA) ? "+" : "-";
        return String.format("%-28s | %-22s | %s R$%10.2f | Saldo: R$%10.2f",
                dataHora.format(fmt), descricao, sinal, valor, saldoApos);
    }
}