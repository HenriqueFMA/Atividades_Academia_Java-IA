package atividade_8.teste;


import atividade_8.controller.ContaCorrenteController;
import atividade_8.model.ContaCorrente;
import atividade_8.model.Transacao;

import java.util.List;

public class ContaCorrenteTest {

    private static int passou = 0;
    private static int falhou = 0;

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║     TESTES AUTOMATIZADOS             ║");
        System.out.println("╚══════════════════════════════════════╝\n");

        ContaCorrenteController ctrl = new ContaCorrenteController();

        System.out.println("\n[VALIDAÇÃO DE CPF]\n");
        ContaCorrente cInvalida1 = ctrl.criarConta("Teste", "Inválido", "111.111.111-11", 500.0);
        testar("CPF inválido (todos iguais) recusado", cInvalida1 == null);

        ContaCorrente cInvalida2 = ctrl.criarConta("Teste", "Inválido", "123.456.789-00", 500.0);
        testar("CPF inválido (dígitos verificadores errados) recusado", cInvalida2 == null);

        ContaCorrente cInvalida3 = ctrl.criarConta("Teste", "Inválido", "12345678900", 500.0);
        testar("CPF inválido (sem formatação válida) recusado", cInvalida3 == null);

        ContaCorrente cInvalida4 = ctrl.criarConta("Teste", "Inválido", "123.456.789", 500.0);
        testar("CPF inválido (muito curto) recusado", cInvalida4 == null);


        ContaCorrente c1 = ctrl.criarConta("João",  "Silva",   "123.456.789-09", 500.0);
        ContaCorrente c2 = ctrl.criarConta("Maria", "Oliveira","987.654.321-00", 200.0);

        testar("Conta 1 criada com CPF válido",          c1 != null);
        testar("Conta 2 criada com CPF válido",          c2 != null);


        System.out.println("\n[VALIDAÇÃO DE CPF DUPLICADO]\n");
        ContaCorrente cDuplicada = ctrl.criarConta("Outro", "Cliente", "123.456.789-09", 1000.0);
        testar("CPF duplicado recusado", cDuplicada == null);

        System.out.println("\n[OPERAÇÕES BANCÁRIAS]\n");
        testar("Saldo inicial c1=500",    c1.getSaldo() == 500.0);
        testar("Saldo inicial c2=200",    c2.getSaldo() == 200.0);
        testar("Nome completo c1",        c1.getCliente().getNomeCompleto().equals("João Silva"));

        String depositoSucesso = ctrl.depositar(c1.getNumero(), 300.0);
        testar("Depósito R$300 em c1",    c1.getSaldo() == 800.0);
        testar("Mensagem de sucesso no depósito", depositoSucesso.contains("✔"));

        String resultInvalid = ctrl.depositar(c1.getNumero(), -50);
        testar("Depósito negativo recusado", resultInvalid.contains("✘"));

        String depositoZero = ctrl.depositar(c1.getNumero(), 0);
        testar("Depósito com valor zero recusado", depositoZero.contains("✘"));

        String saqueSucesso = ctrl.sacar(c1.getNumero(), 100.0);
        testar("Saque R$100 de c1",       c1.getSaldo() == 700.0);
        testar("Mensagem de sucesso no saque", saqueSucesso.contains("✔"));

        String saqueNegativo = ctrl.sacar(c1.getNumero(), -50);
        testar("Saque negativo recusado", saqueNegativo.contains("✘"));

        String saqueInsuf = ctrl.sacar(c1.getNumero(), 9999.0);
        testar("Saque insuficiente recusado", saqueInsuf.contains("✘"));
        testar("Saldo c1 inalterado após saque recusado", c1.getSaldo() == 700.0);

        String saqueZero = ctrl.sacar(c1.getNumero(), 0);
        testar("Saque com valor zero recusado", saqueZero.contains("✘"));

        String saqueExato = ctrl.sacar(c1.getNumero(), 700.0);
        testar("Saque do valor exato do saldo permitido", saqueExato.contains("✔"));
        testar("Saldo zerado após saque exato", c1.getSaldo() == 0.0);


        ctrl.depositar(c1.getNumero(), 500.0);

        String transfSucesso = ctrl.transferir(c1.getNumero(), c2.getNumero(), 200.0);
        testar("Transferência R$200 c1→c2", c1.getSaldo() == 300.0);
        testar("Mensagem de sucesso na transferência", transfSucesso.contains("✔"));
        testar("c2 recebeu R$200",          c2.getSaldo() == 400.0);

        String transfNegativo = ctrl.transferir(c1.getNumero(), c2.getNumero(), -50);
        testar("Transferência negativa recusada", transfNegativo.contains("✘"));

        String transfZero = ctrl.transferir(c1.getNumero(), c2.getNumero(), 0);
        testar("Transferência com valor zero recusada", transfZero.contains("✘"));

        String transfNeg = ctrl.transferir(c1.getNumero(), c2.getNumero(), 9999.0);
        testar("Transferência que zeraria saldo cancelada", transfNeg.contains("✘"));
        testar("Saldo c1 inalterado após transf cancelada", c1.getSaldo() == 300.0);

        String transfInexistente = ctrl.transferir(c1.getNumero(), 9999, 100.0);
        testar("Transferência para conta inexistente recusada", transfInexistente.contains("✘"));

        String contaInexistente = ctrl.obterSaldo(9999);
        testar("Consulta de conta inexistente retorna erro", contaInexistente.contains("✘"));

        var buscaSucesso = ctrl.buscarPorNumero(c1.getNumero());
        testar("Busca de conta existente retorna resultado", buscaSucesso.isPresent() && buscaSucesso.get() == c1);

        var buscaFalha = ctrl.buscarPorNumero(9999);
        testar("Busca de conta inexistente retorna vazio", buscaFalha.isEmpty());

        System.out.println("\n[EXTRATO E TRANSAÇÕES]\n");
        List<Transacao> extrato1 = c1.getExtrato();
        testar("Extrato c1 tem 6 transações", extrato1.size() == 6);

        long entradas = extrato1.stream()
                .filter(t -> t.getTipo() == Transacao.Tipo.DEPOSITO
                          || t.getTipo() == Transacao.Tipo.TRANSFERENCIA_ENTRADA)
                .count();
        long saidas = extrato1.stream()
                .filter(t -> t.getTipo() == Transacao.Tipo.SAQUE
                          || t.getTipo() == Transacao.Tipo.TRANSFERENCIA_SAIDA)
                .count();
        testar("c1 tem entradas no extrato",  entradas > 0);
        testar("c1 tem saídas no extrato",    saidas > 0);

        String extratoOculto = ctrl.obterExtrato(c1.getNumero(), false);
        testar("Extrato com saldo oculto contém '****'", extratoOculto.contains("****"));
        testar("Extrato com saldo oculto oculta coluna Saldo",
                !extratoOculto.contains("Saldo: 500") && !extratoOculto.contains("Saldo: 800"));

        String extratoVisivel = ctrl.obterExtrato(c1.getNumero(), true);
        testar("Extrato visível contém saldo real", extratoVisivel.contains("500,00")
                || extratoVisivel.contains("500.00"));

        String extratoInexistente = ctrl.obterExtrato(9999, true);
        testar("Extrato de conta inexistente retorna erro", extratoInexistente.contains("✘"));

        System.out.println("\n[LISTAGEM DE CONTAS]\n");
        List<ContaCorrente> contas = ctrl.listarContas();
        testar("Listagem contém 2 contas", contas.size() == 2);
        testar("Contas listadas contêm c1", contas.contains(c1));
        testar("Contas listadas contêm c2", contas.contains(c2));

        System.out.println("\n[RESULTADO]\n");

        System.out.println("\n" + "═".repeat(50));
        System.out.printf("  Resultado: %d passou(ram) | %d falhou(ram)%n", passou, falhou);
        System.out.println("═".repeat(50));

        if (falhou == 0) {
            System.out.println("  ✅ TODOS OS TESTES PASSARAM!");
        } else {
            System.out.println("  ❌ ALGUNS TESTES FALHARAM.");
            System.exit(1);
        }

        System.out.println("\n── EXTRATO DE EXEMPLO (c1 – saldo visível) ──");
        System.out.println(ctrl.obterExtrato(c1.getNumero(), true));
    }

    private static void testar(String descricao, boolean condicao) {
        if (condicao) {
            System.out.printf("  ✅ %s%n", descricao);
            passou++;
        } else {
            System.out.printf("  ❌ FALHOU: %s%n", descricao);
            falhou++;
        }
    }
}