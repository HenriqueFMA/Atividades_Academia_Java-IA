package atividade_8;

import atividade_8.controller.ContaCorrenteController;
import atividade_8.view.MenuView;

public class PrincipalContaCorrente {

    public static void main(String[] args) {
        ContaCorrenteController controller = new ContaCorrenteController();
        MenuView menu = new MenuView(controller);
        menu.iniciar();
    }
}