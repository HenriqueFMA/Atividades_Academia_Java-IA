package atividade_8.view;

import atividade_8.controller.ContaCorrenteController;
import atividade_8.model.ContaCorrente;

import java.util.List;
import java.util.Scanner;

public class MenuView {

    private final ContaCorrenteController controller;
    private final Scanner scanner;
    private boolean saldoVísivel = true;

    public MenuView(ContaCorrenteController controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    public void iniciar() {
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   SISTEMA BANCÁRIO - CONTA CORRENTE  ║");
        System.out.println("╚══════════════════════════════════════╝");

        int opcao;
        do {
            exibirMenu();
            opcao = lerInt("Opção: ");

            switch (opcao) {
                case 1 -> criarConta();
                case 2 -> depositar();
                case 3 -> sacar();
                case 4 -> transferir();
                case 5 -> verExtrato();
                case 6 -> verSaldo();
                case 7 -> toggleSaldo();
                case 8 -> listarContas();
                case 0 -> System.out.println("\n👋 Sistema encerrado. Até logo!");
                default -> System.out.println("⚠ Opção inválida. Tente novamente.\n");
            }
        } while (opcao != 0);
    }


    private void exibirMenu() {
        String statusSaldo = saldoVísivel ? "👁  Visível" : "🙈 Oculto";
        System.out.println("\n┌─────────────────────────────────────┐");
        System.out.printf ("│  Saldo: %-28s│%n", statusSaldo);
        System.out.println("├─────────────────────────────────────┤");
        System.out.println("│  1. Criar Conta                     │");
        System.out.println("│  2. Depositar                       │");
        System.out.println("│  3. Sacar                           │");
        System.out.println("│  4. Transferir                      │");
        System.out.println("│  5. Ver Extrato                     │");
        System.out.println("│  6. Ver Saldo                       │");
        System.out.println("│  7. Mostrar/Esconder Saldo          │");
        System.out.println("│  8. Listar Contas                   │");
        System.out.println("│  0. Sair                            │");
        System.out.println("└─────────────────────────────────────┘");
    }


    private void criarConta() {
        System.out.println("\n── CRIAR CONTA ──");
        String nome      = lerString("Nome: ");
        String sobrenome = lerString("Sobrenome: ");
        String cpf       = lerString("CPF: ");
        double saldo     = lerDouble("Saldo inicial (R$): ");
        ContaCorrente c  = controller.criarConta(nome, sobrenome, cpf, saldo);

        if (c != null) {
            System.out.printf("✔ Conta #%d criada para %s %s.%n", c.getNumero(), nome, sobrenome);
        } else {
            System.out.println("⚠ Falha ao criar conta. Verifique os dados e tente novamente.");
        }
    }

    private void depositar() {
        System.out.println("\n── DEPÓSITO ──");
        int    numero = lerInt("Número da conta: ");
        double valor  = lerDouble("Valor (R$): ");
        System.out.println(controller.depositar(numero, valor));
    }

    private void sacar() {
        System.out.println("\n── SAQUE ──");
        int    numero = lerInt("Número da conta: ");
        double valor  = lerDouble("Valor (R$): ");
        System.out.println(controller.sacar(numero, valor));
    }

    private void transferir() {
        System.out.println("\n── TRANSFERÊNCIA ──");
        int    origem  = lerInt("Conta de origem: ");
        int    destino = lerInt("Conta de destino: ");
        double valor   = lerDouble("Valor (R$): ");
        System.out.println(controller.transferir(origem, destino, valor));
    }

    private void verExtrato() {
        System.out.println("\n── EXTRATO ──");
        int numero = lerInt("Número da conta: ");
        System.out.println(controller.obterExtrato(numero, saldoVísivel));
    }

    private void verSaldo() {
        System.out.println("\n── SALDO ──");
        if (!saldoVísivel) {
            System.out.println("🙈 Saldo está oculto. Use a opção 7 para exibir.");
            return;
        }
        int numero = lerInt("Número da conta: ");
        System.out.println(controller.obterSaldo(numero));
    }

    private void toggleSaldo() {
        saldoVísivel = !saldoVísivel;
        System.out.println(saldoVísivel
                ? "✔ Saldo agora está VISÍVEL."
                : "✔ Saldo agora está OCULTO.");
    }

    private void listarContas() {
        List<ContaCorrente> contas = controller.listarContas();
        if (contas.isEmpty()) {
            System.out.println("Nenhuma conta cadastrada.");
            return;
        }
        System.out.println("\n── CONTAS CADASTRADAS ──");
        for (ContaCorrente c : contas) {
            System.out.printf("  #%d | %s | CPF: %s%n",
                    c.getNumero(),
                    c.getCliente().getNomeCompleto(),
                    c.getCliente().getCpf());
        }
    }

    private int lerInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try { return Integer.parseInt(scanner.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("⚠ Digite um número inteiro válido."); }
        }
    }

    private double lerDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try { return Double.parseDouble(scanner.nextLine().trim().replace(",", ".")); }
            catch (NumberFormatException e) { System.out.println("⚠ Digite um valor numérico válido."); }
        }
    }

    private String lerString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
}