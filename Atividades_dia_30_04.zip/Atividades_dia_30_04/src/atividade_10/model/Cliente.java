package atividade_10.model;

import atividade_10.exception.DadosInvalidosException;

public class Cliente {

    private String customerId;
    private String nome;
    private String email;

    public Cliente(String customerId, String nome, String email) throws DadosInvalidosException {
        setCustomerId(customerId);
        setNome(nome);
        setEmail(email);
    }



    public String getCustomerId() {
        return customerId;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }



    public void setCustomerId(String customerId) throws DadosInvalidosException {
        if (customerId == null || customerId.trim().isEmpty()) {
            throw new DadosInvalidosException("CustomerId nao pode ser nulo ou vazio.");
        }
        this.customerId = customerId.trim();
    }

    public void setNome(String nome) throws DadosInvalidosException {
        if (nome == null || nome.trim().isEmpty()) {
            throw new DadosInvalidosException("Nome do cliente nao pode ser nulo ou vazio.");
        }
        this.nome = nome.trim();
    }

    public void setEmail(String email) throws DadosInvalidosException {
        if (email == null || email.trim().isEmpty()) {
            throw new DadosInvalidosException("Email nao pode ser nulo ou vazio.");
        }
        if (!email.contains("@")) {
            throw new DadosInvalidosException("Email invalido: " + email);
        }
        this.email = email.trim().toLowerCase();
    }

    @Override
    public String toString() {
        return String.format("[ID: %-10s | Nome: %-20s | Email: %s]", customerId, nome, email);
    }
}
