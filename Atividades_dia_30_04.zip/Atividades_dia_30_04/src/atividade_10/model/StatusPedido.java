package atividade_10.model;

public enum StatusPedido {
    CREATED,
    RESERVED,
    PAID,
    FAILED,
    CANCELLED
}
