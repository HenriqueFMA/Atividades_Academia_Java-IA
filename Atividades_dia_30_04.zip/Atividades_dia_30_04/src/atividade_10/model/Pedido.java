package atividade_10.model;

import atividade_10.exception.DadosInvalidosException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Pedido {

    private String pedidoId;
    private Cliente cliente;
    private List<ItemPedido> itens;
    private StatusPedido status;
    private double desconto;
    private LocalDateTime dataCriacao;

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public Pedido(String pedidoId, Cliente cliente) throws DadosInvalidosException {
        setPedidoId(pedidoId);
        setCliente(cliente);
        this.itens = new ArrayList<>();
        this.status = StatusPedido.CREATED;
        this.desconto = 0.0;
        this.dataCriacao = LocalDateTime.now();
    }



    public String getPedidoId() {
        return pedidoId;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<ItemPedido> getItens() {
        return Collections.unmodifiableList(itens);
    }

    public StatusPedido getStatus() {
        return status;
    }

    public double getDesconto() {
        return desconto;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public double getTotalBruto() {
        double total = 0;
        for (ItemPedido item : itens) {
            total += item.getSubtotal();
        }
        return total;
    }

    public double getTotalLiquido() {
        return getTotalBruto() - desconto;
    }



    public void setPedidoId(String pedidoId) throws DadosInvalidosException {
        if (pedidoId == null || pedidoId.trim().isEmpty()) {
            throw new DadosInvalidosException("PedidoId nao pode ser nulo ou vazio.");
        }
        this.pedidoId = pedidoId.trim();
    }

    public void setCliente(Cliente cliente) throws DadosInvalidosException {
        if (cliente == null) {
            throw new DadosInvalidosException("Cliente do pedido nao pode ser nulo.");
        }
        this.cliente = cliente;
    }

    public void setStatus(StatusPedido status) throws DadosInvalidosException {
        if (status == null) {
            throw new DadosInvalidosException("Status do pedido nao pode ser nulo.");
        }
        this.status = status;
    }

    public void setDesconto(double desconto) throws DadosInvalidosException {
        if (desconto < 0) {
            throw new DadosInvalidosException("Desconto nao pode ser negativo.");
        }
        if (desconto > getTotalBruto()) {
            throw new DadosInvalidosException("Desconto nao pode ser maior que o total bruto.");
        }
        this.desconto = desconto;
    }

    public void adicionarItem(ItemPedido item) throws DadosInvalidosException {
        if (item == null) {
            throw new DadosInvalidosException("Item do pedido nao pode ser nulo.");
        }
        this.itens.add(item);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("========================================%n"));
        sb.append(String.format(" PEDIDO ID : %s%n", pedidoId));
        sb.append(String.format(" CLIENTE   : %s (%s)%n", cliente.getNome(), cliente.getCustomerId()));
        sb.append(String.format(" STATUS    : %s%n", status));
        sb.append(String.format(" DATA      : %s%n", dataCriacao.format(FORMATTER)));
        sb.append(String.format(" ITENS:%n"));
        for (ItemPedido item : itens) {
            sb.append(item.toString()).append(System.lineSeparator());
        }
        sb.append(String.format(" TOTAL BRUTO : R$ %.2f%n", getTotalBruto()));
        sb.append(String.format(" DESCONTO    : R$ %.2f%n", desconto));
        sb.append(String.format(" TOTAL LIQ.  : R$ %.2f%n", getTotalLiquido()));
        sb.append(String.format("========================================%n"));
        return sb.toString();
    }
}
