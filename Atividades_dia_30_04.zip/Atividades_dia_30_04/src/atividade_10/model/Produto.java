package atividade_10.model;

import atividade_10.exception.DadosInvalidosException;

public class Produto {

    private String sku;
    private String nome;
    private String categoria;
    private double preco;
    private int estoque;

    public Produto(String sku, String nome, String categoria, double preco, int estoque)
            throws DadosInvalidosException {
        setSku(sku);
        setNome(nome);
        setCategoria(categoria);
        setPreco(preco);
        setEstoque(estoque);
    }



    public String getSku() {
        return sku;
    }

    public String getNome() {
        return nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getPreco() {
        return preco;
    }

    public int getEstoque() {
        return estoque;
    }



    public void setSku(String sku) throws DadosInvalidosException {
        if (sku == null || sku.trim().isEmpty()) {
            throw new DadosInvalidosException("SKU nao pode ser nulo ou vazio.");
        }
        this.sku = sku.trim().toUpperCase();
    }

    public void setNome(String nome) throws DadosInvalidosException {
        if (nome == null || nome.trim().isEmpty()) {
            throw new DadosInvalidosException("Nome do produto nao pode ser nulo ou vazio.");
        }
        this.nome = nome.trim();
    }

    public void setCategoria(String categoria) throws DadosInvalidosException {
        if (categoria == null || categoria.trim().isEmpty()) {
            throw new DadosInvalidosException("Categoria nao pode ser nula ou vazia.");
        }
        this.categoria = categoria.trim();
    }

    public void setPreco(double preco) throws DadosInvalidosException {
        if (preco < 0) {
            throw new DadosInvalidosException("Preco nao pode ser negativo. Valor informado: " + preco);
        }
        this.preco = preco;
    }

    public void setEstoque(int estoque) throws DadosInvalidosException {
        if (estoque < 0) {
            throw new DadosInvalidosException("Estoque nao pode ser negativo. Valor informado: " + estoque);
        }
        this.estoque = estoque;
    }

    @Override
    public String toString() {
        return String.format("[SKU: %-10s | Nome: %-20s | Categoria: %-15s | Preco: R$ %8.2f | Estoque: %d]",
                sku, nome, categoria, preco, estoque);
    }
}
