package atividade_10.model;

import atividade_10.exception.DadosInvalidosException;

public class ItemPedido {

    private Produto produto;
    private int quantidade;
    private double precoUnitario;

    public ItemPedido(Produto produto, int quantidade) throws DadosInvalidosException {
        setProduto(produto);
        setQuantidade(quantidade);
        this.precoUnitario = produto.getPreco();
    }



    public Produto getProduto() {
        return produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public double getSubtotal() {
        return precoUnitario * quantidade;
    }



    public void setProduto(Produto produto) throws DadosInvalidosException {
        if (produto == null) {
            throw new DadosInvalidosException("Produto do item nao pode ser nulo.");
        }
        this.produto = produto;
    }

    public void setQuantidade(int quantidade) throws DadosInvalidosException {
        if (quantidade <= 0) {
            throw new DadosInvalidosException("Quantidade deve ser maior que zero. Valor informado: " + quantidade);
        }
        this.quantidade = quantidade;
    }

    public void setPrecoUnitario(double precoUnitario) throws DadosInvalidosException {
        if (precoUnitario < 0) {
            throw new DadosInvalidosException("Preco unitario nao pode ser negativo.");
        }
        this.precoUnitario = precoUnitario;
    }

    @Override
    public String toString() {
        return String.format("  -> SKU: %-10s | Produto: %-20s | Qtd: %3d | Unit: R$ %8.2f | Subtotal: R$ %8.2f",
                produto.getSku(), produto.getNome(), quantidade, precoUnitario, getSubtotal());
    }
}
