package atividade_10.view;

import atividade_10.controller.ClienteController;
import atividade_10.controller.PedidoController;
import atividade_10.controller.ProdutoController;
import atividade_10.exception.*;
import atividade_10.model.Pedido;
import atividade_10.model.Produto;

import java.util.*;

public class MenuCLI {

    private final Scanner scanner;
    private final ProdutoController produtoController;
    private final ClienteController clienteController;
    private final PedidoController pedidoController;

    public MenuCLI() {
        this.scanner = new Scanner(System.in);
        this.produtoController = new ProdutoController();
        this.clienteController = new ClienteController();
        this.pedidoController = new PedidoController(produtoController, clienteController);
    }

    public void iniciar() {
        System.out.println("============================================");
        System.out.println("  SIMULADOR DE PROCESSAMENTO DE PEDIDOS   ");
        System.out.println("         E-Commerce CLI - Atividade 10    ");
        System.out.println("============================================");

        boolean executando = true;
        while (executando) {
            exibirMenuPrincipal();
            int opcao = lerInteiroSeguro("Escolha uma opcao: ");
            try {
                switch (opcao) {
                    case 1:  menuProdutos();    break;
                    case 2:  menuClientes();    break;
                    case 3:  menuPedidos();     break;
                    case 4:  menuRelatorios();  break;
                    case 0:
                        executando = false;
                        System.out.println("Sistema encerrado. Ate logo!");
                        break;
                    default:
                        System.out.println("[AVISO] Opcao invalida. Tente novamente.");
                }
            } catch (Exception e) {
                System.out.println("[ERRO INESPERADO] " + e.getMessage());
            }
        }
        scanner.close();
    }



    private void exibirMenuPrincipal() {
        System.out.println("\n--- MENU PRINCIPAL ---");
        System.out.println("1 - Gerenciar Produtos");
        System.out.println("2 - Gerenciar Clientes");
        System.out.println("3 - Gerenciar Pedidos");
        System.out.println("4 - Relatorios");
        System.out.println("0 - Sair");
        System.out.println("----------------------");
    }



    private void menuProdutos() {
        boolean volta = false;
        while (!volta) {
            System.out.println("\n--- PRODUTOS ---");
            System.out.println("1 - Adicionar produto");
            System.out.println("2 - Listar por SKU");
            System.out.println("3 - Listar por preco");
            System.out.println("0 - Voltar");

            int op = lerInteiroSeguro("Opcao: ");
            switch (op) {
                case 1: adicionarProduto();  break;
                case 2: listarProdutosPorSku();   break;
                case 3: listarProdutosPorPreco(); break;
                case 0: volta = true; break;
                default: System.out.println("[AVISO] Opcao invalida.");
            }
        }
    }

    private void adicionarProduto() {
        try {
            System.out.println("\n-- Adicionar Produto --");
            String sku       = lerStringObrigatoria("SKU: ");
            String nome      = lerStringObrigatoria("Nome: ");
            String categoria = lerStringObrigatoria("Categoria: ");
            double preco     = lerDoubleSeguro("Preco: ");
            int estoque      = lerInteiroSeguro("Estoque inicial: ");

            produtoController.adicionarProduto(sku, nome, categoria, preco, estoque);

        } catch (DadosInvalidosException e) {
            System.out.println("[ERRO] " + e.getMessage());
        }
    }

    private void listarProdutosPorSku() {
        List<Produto> lista = produtoController.listarPorSku();
        if (lista.isEmpty()) {
            System.out.println("[INFO] Nenhum produto cadastrado.");
            return;
        }
        System.out.println("\n-- Produtos ordenados por SKU --");
        for (Produto p : lista) {
            System.out.println(p);
        }
    }

    private void listarProdutosPorPreco() {
        List<Produto> lista = produtoController.listarPorPreco();
        if (lista.isEmpty()) {
            System.out.println("[INFO] Nenhum produto cadastrado.");
            return;
        }
        System.out.println("\n-- Produtos ordenados por Preco --");
        for (Produto p : lista) {
            System.out.println(p);
        }
    }



    private void menuClientes() {
        boolean volta = false;
        while (!volta) {
            System.out.println("\n--- CLIENTES ---");
            System.out.println("1 - Adicionar cliente");
            System.out.println("2 - Listar clientes");
            System.out.println("0 - Voltar");

            int op = lerInteiroSeguro("Opcao: ");
            switch (op) {
                case 1: adicionarCliente(); break;
                case 2: listarClientes();   break;
                case 0: volta = true; break;
                default: System.out.println("[AVISO] Opcao invalida.");
            }
        }
    }

    private void adicionarCliente() {
        try {
            System.out.println("\n-- Adicionar Cliente --");
            String id    = lerStringObrigatoria("Customer ID: ");
            String nome  = lerStringObrigatoria("Nome: ");
            String email = lerStringObrigatoria("Email: ");

            clienteController.adicionarCliente(id, nome, email);

        } catch (DadosInvalidosException e) {
            System.out.println("[ERRO] " + e.getMessage());
        }
    }

    private void listarClientes() {
        var lista = clienteController.getTodosClientes();
        if (lista.isEmpty()) {
            System.out.println("[INFO] Nenhum cliente cadastrado.");
            return;
        }
        System.out.println("\n-- Lista de Clientes --");
        for (var c : lista) {
            System.out.println(c);
        }
    }



    private void menuPedidos() {
        boolean volta = false;
        while (!volta) {
            System.out.println("\n--- PEDIDOS ---");
            System.out.println("1 - Criar pedido");
            System.out.println("2 - Reservar estoque");
            System.out.println("3 - Pagar pedido");
            System.out.println("4 - Cancelar pedido");
            System.out.println("5 - Listar todos os pedidos");
            System.out.println("0 - Voltar");

            int op = lerInteiroSeguro("Opcao: ");
            switch (op) {
                case 1: criarPedido();         break;
                case 2: reservarEstoque();     break;
                case 3: pagarPedido();         break;
                case 4: cancelarPedido();      break;
                case 5: listarPedidos();       break;
                case 0: volta = true; break;
                default: System.out.println("[AVISO] Opcao invalida.");
            }
        }
    }

    private void criarPedido() {
        try {
            System.out.println("\n-- Criar Pedido --");
            String customerId = lerStringObrigatoria("Customer ID: ");

            Map<String, Integer> itens = new LinkedHashMap<>();
            System.out.println("Adicione os itens (SKU + quantidade). Digite 'fim' para encerrar.");
            while (true) {
                String sku = lerStringObrigatoria("  SKU (ou 'fim'): ");
                if (sku.equalsIgnoreCase("fim")) break;
                int qtd = lerInteiroSeguro("  Quantidade: ");
                itens.put(sku, qtd);
            }

            pedidoController.criarPedido(customerId, itens);

        } catch (ClienteNaoEncontradoException | ProdutoNaoEncontradoException | DadosInvalidosException e) {
            System.out.println("[ERRO] " + e.getMessage());
        }
    }

    private void reservarEstoque() {
        try {
            String pedidoId = lerStringObrigatoria("ID do pedido para reservar estoque: ");
            pedidoController.reservarEstoque(pedidoId);
        } catch (PedidoNaoEncontradoException | EstoqueInsuficienteException
                | StatusPedidoInvalidoException | DadosInvalidosException e) {
            System.out.println("[ERRO] " + e.getMessage());
        }
    }

    private void pagarPedido() {
        try {
            String pedidoId = lerStringObrigatoria("ID do pedido para pagar: ");
            double desconto = lerDoubleSeguro("Desconto (0 para nenhum): ");
            System.out.print("Simular pagamento aprovado? (s/n): ");
            String resp = scanner.nextLine().trim();
            boolean aprovado = resp.equalsIgnoreCase("s");
            pedidoController.pagarPedido(pedidoId, desconto, aprovado);
        } catch (PedidoNaoEncontradoException | StatusPedidoInvalidoException | DadosInvalidosException e) {
            System.out.println("[ERRO] " + e.getMessage());
        }
    }

    private void cancelarPedido() {
        try {
            String pedidoId = lerStringObrigatoria("ID do pedido para cancelar: ");
            pedidoController.cancelarPedido(pedidoId);
        } catch (PedidoNaoEncontradoException | StatusPedidoInvalidoException | DadosInvalidosException e) {
            System.out.println("[ERRO] " + e.getMessage());
        }
    }

    private void listarPedidos() {
        var lista = pedidoController.getTodosPedidos();
        if (lista.isEmpty()) {
            System.out.println("[INFO] Nenhum pedido cadastrado.");
            return;
        }
        for (Pedido p : lista) {
            System.out.println(p);
        }
    }



    private void menuRelatorios() {
        System.out.println("\n========== RELATORIOS ==========");


        double faturamento = pedidoController.getFaturamentoTotal();
        System.out.printf("%n[1] Faturamento Total (pedidos PAID): R$ %.2f%n", faturamento);


        System.out.println("\n[2] Top 3 Produtos Mais Vendidos (por quantidade):");
        var top3 = pedidoController.getTop3ProdutosMaisVendidos();
        if (top3.isEmpty()) {
            System.out.println("  Nenhum pedido PAID registrado.");
        } else {
            int rank = 1;
            for (var entry : top3) {
                System.out.printf("  %d. SKU: %-10s | Qtd vendida: %d%n", rank++, entry.getKey(), entry.getValue());
            }
        }


        System.out.println("\n[3] Faturamento por Categoria:");
        var porCategoria = pedidoController.getFaturamentoPorCategoria();
        if (porCategoria.isEmpty()) {
            System.out.println("  Nenhum pedido PAID registrado.");
        } else {
            for (var entry : porCategoria.entrySet()) {
                System.out.printf("  %-20s : R$ %.2f%n", entry.getKey(), entry.getValue());
            }
        }


        System.out.println("\n[4] Clientes com Maior Numero de Pedidos:");
        var clientesRank = pedidoController.getClientesComMaisPedidos();
        if (clientesRank.isEmpty()) {
            System.out.println("  Nenhum pedido registrado.");
        } else {
            for (var entry : clientesRank) {
                System.out.printf("  ID: %-10s | Pedidos: %d%n", entry.getKey(), entry.getValue());
            }
        }

        System.out.println("\n================================");
    }



    private String lerStringObrigatoria(String label) {
        while (true) {
            try {
                System.out.print(label);
                String valor = scanner.nextLine().trim();
                if (valor.isEmpty()) {
                    System.out.println("[AVISO] Campo obrigatorio. Tente novamente.");
                    continue;
                }
                return valor;
            } catch (NoSuchElementException e) {
                System.out.println("[ERRO] Entrada encerrada inesperadamente.");
                return "";
            }
        }
    }

    private int lerInteiroSeguro(String label) {
        while (true) {
            try {
                System.out.print(label);
                String linha = scanner.nextLine().trim();
                return Integer.parseInt(linha);
            } catch (NumberFormatException e) {
                System.out.println("[AVISO] Entrada invalida. Digite um numero inteiro.");
            } catch (NoSuchElementException e) {
                System.out.println("[ERRO] Entrada encerrada inesperadamente.");
                return 0;
            }
        }
    }

    private double lerDoubleSeguro(String label) {
        while (true) {
            try {
                System.out.print(label);
                String linha = scanner.nextLine().trim().replace(",", ".");
                return Double.parseDouble(linha);
            } catch (NumberFormatException e) {
                System.out.println("[AVISO] Entrada invalida. Digite um numero (ex: 29.90).");
            } catch (NoSuchElementException e) {
                System.out.println("[ERRO] Entrada encerrada inesperadamente.");
                return 0.0;
            }
        }
    }
}
