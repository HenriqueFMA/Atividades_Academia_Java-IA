package atividade_10.controller;

import atividade_10.exception.ClienteNaoEncontradoException;
import atividade_10.exception.DadosInvalidosException;
import atividade_10.model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteController {

    private final List<Cliente> clientes;

    public ClienteController() {
        this.clientes = new ArrayList<>();
    }

    public void adicionarCliente(String customerId, String nome, String email)
            throws DadosInvalidosException {
        try {
            if (existeCliente(customerId)) {
                throw new DadosInvalidosException("Ja existe um cliente com o ID '" + customerId + "'.");
            }
            Cliente cliente = new Cliente(customerId, nome, email);
            clientes.add(cliente);
            System.out.println("[OK] Cliente adicionado: " + cliente);
        } catch (DadosInvalidosException e) {
            throw e;
        }
    }

    public Cliente buscarPorId(String customerId)
            throws ClienteNaoEncontradoException, DadosInvalidosException {
        try {
            if (customerId == null || customerId.trim().isEmpty()) {
                throw new DadosInvalidosException("CustomerId para busca nao pode ser nulo ou vazio.");
            }
            for (Cliente c : clientes) {
                if (c.getCustomerId().equalsIgnoreCase(customerId.trim())) {
                    return c;
                }
            }
            throw new ClienteNaoEncontradoException(customerId);
        } catch (DadosInvalidosException | ClienteNaoEncontradoException e) {
            throw e;
        }
    }

    public boolean existeCliente(String customerId) {
        for (Cliente c : clientes) {
            if (c.getCustomerId().equalsIgnoreCase(customerId != null ? customerId.trim() : "")) {
                return true;
            }
        }
        return false;
    }

    public List<Cliente> getTodosClientes() {
        return new ArrayList<>(clientes);
    }
}
