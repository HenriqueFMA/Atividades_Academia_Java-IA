package atividade_10.controller;

import atividade_10.exception.DadosInvalidosException;
import atividade_10.exception.ProdutoNaoEncontradoException;
import atividade_10.model.Produto;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ProdutoController {

    private final List<Produto> produtos;

    public ProdutoController() {
        this.produtos = new ArrayList<>();
    }

    public void adicionarProduto(String sku, String nome, String categoria, double preco, int estoque)
            throws DadosInvalidosException {
        try {

            if (existeProduto(sku)) {
                throw new DadosInvalidosException("Ja existe um produto com o SKU '" + sku + "'.");
            }
            Produto produto = new Produto(sku, nome, categoria, preco, estoque);
            produtos.add(produto);
            System.out.println("[OK] Produto adicionado: " + produto);
        } catch (DadosInvalidosException e) {
            throw e;
        }
    }

    public Produto buscarPorSku(String sku) throws ProdutoNaoEncontradoException, DadosInvalidosException {
        try {
            if (sku == null || sku.trim().isEmpty()) {
                throw new DadosInvalidosException("SKU para busca nao pode ser nulo ou vazio.");
            }
            for (Produto p : produtos) {
                if (p.getSku().equalsIgnoreCase(sku.trim())) {
                    return p;
                }
            }
            throw new ProdutoNaoEncontradoException(sku);
        } catch (DadosInvalidosException | ProdutoNaoEncontradoException e) {
            throw e;
        }
    }

    public List<Produto> listarPorSku() {
        List<Produto> lista = new ArrayList<>(produtos);
        lista.sort(Comparator.comparing(Produto::getSku));
        return lista;
    }

    public List<Produto> listarPorPreco() {
        List<Produto> lista = new ArrayList<>(produtos);
        lista.sort(Comparator.comparingDouble(Produto::getPreco));
        return lista;
    }

    public boolean existeProduto(String sku) {
        for (Produto p : produtos) {
            if (p.getSku().equalsIgnoreCase(sku != null ? sku.trim() : "")) {
                return true;
            }
        }
        return false;
    }

    public List<Produto> getTodosProdutos() {
        return new ArrayList<>(produtos);
    }
}
