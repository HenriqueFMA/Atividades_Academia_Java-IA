package atividade_10.controller;

import java.util.*;
import atividade_10.exception.*;
import atividade_10.model.*;


public class PedidoController {

    private final List<Pedido> pedidos;
    private final ProdutoController produtoController;
    private final ClienteController clienteController;
    private int contadorId;

    public PedidoController(ProdutoController produtoController, ClienteController clienteController) {
        this.pedidos = new ArrayList<>();
        this.produtoController = produtoController;
        this.clienteController = clienteController;
        this.contadorId = 1;
    }

    public Pedido criarPedido(String customerId, Map<String, Integer> itensMap)
            throws ClienteNaoEncontradoException, ProdutoNaoEncontradoException,
                   DadosInvalidosException {
        try {
            if (itensMap == null || itensMap.isEmpty()) {
                throw new DadosInvalidosException("O pedido deve ter pelo menos um item.");
            }

            Cliente cliente = clienteController.buscarPorId(customerId);
            String pedidoId = "PED-" + String.format("%04d", contadorId++);
            Pedido pedido = new Pedido(pedidoId, cliente);

            for (Map.Entry<String, Integer> entry : itensMap.entrySet()) {
                Produto produto = produtoController.buscarPorSku(entry.getKey());
                ItemPedido item = new ItemPedido(produto, entry.getValue());
                pedido.adicionarItem(item);
            }

            pedidos.add(pedido);
            System.out.println("[OK] Pedido criado: " + pedidoId + " | Cliente: " + cliente.getNome()
                    + " | Total: R$ " + String.format("%.2f", pedido.getTotalBruto()));
            return pedido;

        } catch (ClienteNaoEncontradoException | ProdutoNaoEncontradoException | DadosInvalidosException e) {
            throw e;
        }
    }

    public void reservarEstoque(String pedidoId)
            throws PedidoNaoEncontradoException, EstoqueInsuficienteException,
                   StatusPedidoInvalidoException, DadosInvalidosException {
        try {
            Pedido pedido = buscarPorId(pedidoId);

            if (pedido.getStatus() != StatusPedido.CREATED) {
                throw new StatusPedidoInvalidoException("RESERVAR ESTOQUE", pedido.getStatus().name());
            }


            for (ItemPedido item : pedido.getItens()) {
                Produto prod = item.getProduto();
                if (prod.getEstoque() < item.getQuantidade()) {
                    throw new EstoqueInsuficienteException(
                            prod.getSku(), item.getQuantidade(), prod.getEstoque());
                }
            }


            for (ItemPedido item : pedido.getItens()) {
                Produto prod = item.getProduto();
                prod.setEstoque(prod.getEstoque() - item.getQuantidade());
            }

            pedido.setStatus(StatusPedido.RESERVED);
            System.out.println("[OK] Estoque reservado para pedido: " + pedidoId);

        } catch (EstoqueInsuficienteException | StatusPedidoInvalidoException
                | PedidoNaoEncontradoException | DadosInvalidosException e) {
            throw e;
        }
    }

    public void pagarPedido(String pedidoId, double desconto, boolean pagamentoAprovado)
            throws PedidoNaoEncontradoException, StatusPedidoInvalidoException, DadosInvalidosException {
        try {
            Pedido pedido = buscarPorId(pedidoId);

            if (pedido.getStatus() != StatusPedido.RESERVED) {
                throw new StatusPedidoInvalidoException("PAGAR PEDIDO", pedido.getStatus().name());
            }

            if (desconto > 0) {
                pedido.setDesconto(desconto);
                System.out.println("[INFO] Desconto aplicado: R$ " + String.format("%.2f", desconto));
            }

            if (pagamentoAprovado) {
                pedido.setStatus(StatusPedido.PAID);
                System.out.println("[OK] Pagamento aprovado! Pedido " + pedidoId
                        + " | Total liquido: R$ " + String.format("%.2f", pedido.getTotalLiquido()));
            } else {
                pedido.setStatus(StatusPedido.FAILED);
                System.out.println("[FALHA] Pagamento recusado para pedido: " + pedidoId);
            }

        } catch (StatusPedidoInvalidoException | PedidoNaoEncontradoException | DadosInvalidosException e) {
            throw e;
        }
    }

    public void cancelarPedido(String pedidoId)
            throws PedidoNaoEncontradoException, StatusPedidoInvalidoException, DadosInvalidosException {
        try {
            Pedido pedido = buscarPorId(pedidoId);

            if (pedido.getStatus() == StatusPedido.PAID || pedido.getStatus() == StatusPedido.CANCELLED) {
                throw new StatusPedidoInvalidoException("CANCELAR PEDIDO", pedido.getStatus().name());
            }


            if (pedido.getStatus() == StatusPedido.RESERVED) {
                for (ItemPedido item : pedido.getItens()) {
                    Produto prod = item.getProduto();
                    prod.setEstoque(prod.getEstoque() + item.getQuantidade());
                }
                System.out.println("[INFO] Estoque liberado para pedido cancelado: " + pedidoId);
            }

            pedido.setStatus(StatusPedido.CANCELLED);
            System.out.println("[OK] Pedido " + pedidoId + " cancelado com sucesso.");

        } catch (StatusPedidoInvalidoException | PedidoNaoEncontradoException | DadosInvalidosException e) {
            throw e;
        }
    }

    public Pedido buscarPorId(String pedidoId)
            throws PedidoNaoEncontradoException, DadosInvalidosException {
        if (pedidoId == null || pedidoId.trim().isEmpty()) {
            throw new DadosInvalidosException("PedidoId para busca nao pode ser nulo ou vazio.");
        }
        for (Pedido p : pedidos) {
            if (p.getPedidoId().equalsIgnoreCase(pedidoId.trim())) {
                return p;
            }
        }
        throw new PedidoNaoEncontradoException(pedidoId);
    }

    public List<Pedido> getTodosPedidos() {
        return new ArrayList<>(pedidos);
    }



    public double getFaturamentoTotal() {
        double total = 0;
        for (Pedido p : pedidos) {
            if (p.getStatus() == StatusPedido.PAID) {
                total += p.getTotalLiquido();
            }
        }
        return total;
    }

    public List<Map.Entry<String, Integer>> getTop3ProdutosMaisVendidos() {
        Map<String, Integer> quantidadePorSku = new HashMap<>();
        Map<String, String> nomePorSku = new HashMap<>();

        for (Pedido p : pedidos) {
            if (p.getStatus() == StatusPedido.PAID) {
                for (ItemPedido item : p.getItens()) {
                    String sku = item.getProduto().getSku();
                    quantidadePorSku.merge(sku, item.getQuantidade(), Integer::sum);
                    nomePorSku.put(sku, item.getProduto().getNome());
                }
            }
        }

        List<Map.Entry<String, Integer>> lista = new ArrayList<>(quantidadePorSku.entrySet());
        lista.sort((a, b) -> b.getValue() - a.getValue());

        return lista.size() > 3 ? lista.subList(0, 3) : lista;
    }

    public Map<String, Double> getFaturamentoPorCategoria() {
        Map<String, Double> faturamento = new HashMap<>();
        for (Pedido p : pedidos) {
            if (p.getStatus() == StatusPedido.PAID) {
                for (ItemPedido item : p.getItens()) {
                    String categoria = item.getProduto().getCategoria();
                    faturamento.merge(categoria, item.getSubtotal(), Double::sum);
                }
            }
        }
        return faturamento;
    }

    public List<Map.Entry<String, Integer>> getClientesComMaisPedidos() {
        Map<String, Integer> contagemPorCliente = new HashMap<>();
        Map<String, String> nomePorId = new HashMap<>();

        for (Pedido p : pedidos) {
            String id = p.getCliente().getCustomerId();
            contagemPorCliente.merge(id, 1, Integer::sum);
            nomePorId.put(id, p.getCliente().getNome());
        }

        List<Map.Entry<String, Integer>> lista = new ArrayList<>(contagemPorCliente.entrySet());
        lista.sort((a, b) -> b.getValue() - a.getValue());
        return lista;
    }
}
