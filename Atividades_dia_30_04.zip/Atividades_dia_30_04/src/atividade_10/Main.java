package atividade_10;

import atividade_10.view.MenuCLI;

public class Main {
    public static void main(String[] args) {
        try {
            MenuCLI menu = new MenuCLI();
            menu.iniciar();
        } catch (Exception e) {
            System.out.println("[ERRO CRITICO] Falha ao iniciar o sistema: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
