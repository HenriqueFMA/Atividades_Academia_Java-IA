package atividade_10.test;

import atividade_10.controller.ClienteController;
import atividade_10.exception.ClienteNaoEncontradoException;
import atividade_10.exception.DadosInvalidosException;
import atividade_10.model.Cliente;

public class ClienteTest {

    private static int totalTestes = 0;
    private static int testesPassados = 0;
    private static int testesFalhados = 0;

    public static void executarTodos() {
        System.out.println("========== TESTES: Cliente ==========");

        testeCriarClienteValido();
        testeGetters();
        testeIdNulo();
        testeIdVazio();
        testeNomeNulo();
        testeEmailSemArroba();
        testeEmailNulo();
        testeBuscarClienteExistente();
        testeBuscarClienteInexistente();
        testeIdDuplicado();
        testeSetterEmailValido();
        testeSetterEmailInvalido();

        imprimirResumo("Cliente");
    }

    private static void testeCriarClienteValido() {
        try {
            Cliente c = new Cliente("C001", "Joao Silva", "joao@email.com");
            assertTrue("ID correto", c.getCustomerId().equals("C001"));
            assertTrue("Nome correto", c.getNome().equals("Joao Silva"));
            assertTrue("Email em minusculo", c.getEmail().equals("joao@email.com"));
            pass("testeCriarClienteValido");
        } catch (Exception e) {
            fail("testeCriarClienteValido", e.getMessage());
        }
    }

    private static void testeGetters() {
        try {
            Cliente c = new Cliente("C002", "Maria Souza", "MARIA@TESTE.COM");
            assertTrue("Email normalizado para minusculo", c.getEmail().equals("maria@teste.com"));
            assertTrue("Nome via getter", c.getNome().equals("Maria Souza"));
            pass("testeGetters");
        } catch (Exception e) {
            fail("testeGetters", e.getMessage());
        }
    }

    private static void testeIdNulo() {
        try {
            new Cliente(null, "Carlos", "carlos@x.com");
            fail("testeIdNulo", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeIdNulo");
        } catch (Exception e) {
            fail("testeIdNulo", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeIdVazio() {
        try {
            new Cliente("  ", "Carlos", "carlos@x.com");
            fail("testeIdVazio", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeIdVazio");
        } catch (Exception e) {
            fail("testeIdVazio", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeNomeNulo() {
        try {
            new Cliente("C003", null, "x@x.com");
            fail("testeNomeNulo", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeNomeNulo");
        } catch (Exception e) {
            fail("testeNomeNulo", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeEmailSemArroba() {
        try {
            new Cliente("C004", "Ana", "anaemail.com");
            fail("testeEmailSemArroba", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeEmailSemArroba");
        } catch (Exception e) {
            fail("testeEmailSemArroba", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeEmailNulo() {
        try {
            new Cliente("C005", "Lucas", null);
            fail("testeEmailNulo", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeEmailNulo");
        } catch (Exception e) {
            fail("testeEmailNulo", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeBuscarClienteExistente() {
        try {
            ClienteController ctrl = new ClienteController();
            ctrl.adicionarCliente("C010", "Pedro", "pedro@test.com");
            Cliente c = ctrl.buscarPorId("C010");
            assertTrue("Cliente encontrado", c.getCustomerId().equals("C010"));
            pass("testeBuscarClienteExistente");
        } catch (Exception e) {
            fail("testeBuscarClienteExistente", e.getMessage());
        }
    }

    private static void testeBuscarClienteInexistente() {
        try {
            ClienteController ctrl = new ClienteController();
            ctrl.buscarPorId("NAOEXISTE");
            fail("testeBuscarClienteInexistente", "Deveria ter lancado ClienteNaoEncontradoException");
        } catch (ClienteNaoEncontradoException e) {
            pass("testeBuscarClienteInexistente");
        } catch (Exception e) {
            fail("testeBuscarClienteInexistente", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeIdDuplicado() {
        try {
            ClienteController ctrl = new ClienteController();
            ctrl.adicionarCliente("C020", "Alice", "alice@x.com");
            ctrl.adicionarCliente("C020", "Bob", "bob@x.com");
            fail("testeIdDuplicado", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeIdDuplicado");
        } catch (Exception e) {
            fail("testeIdDuplicado", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeSetterEmailValido() {
        try {
            Cliente c = new Cliente("C030", "Teste", "old@email.com");
            c.setEmail("new@email.com");
            assertTrue("Email atualizado via setter", c.getEmail().equals("new@email.com"));
            pass("testeSetterEmailValido");
        } catch (Exception e) {
            fail("testeSetterEmailValido", e.getMessage());
        }
    }

    private static void testeSetterEmailInvalido() {
        try {
            Cliente c = new Cliente("C031", "Teste", "valido@email.com");
            c.setEmail("emailsemarroba");
            fail("testeSetterEmailInvalido", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeSetterEmailInvalido");
        } catch (Exception e) {
            fail("testeSetterEmailInvalido", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }



    private static void assertTrue(String descricao, boolean condicao) {
        if (!condicao) throw new AssertionError("Falhou: " + descricao);
    }

    private static void pass(String nome) {
        totalTestes++; testesPassados++;
        System.out.println("  [PASS] " + nome);
    }

    private static void fail(String nome, String motivo) {
        totalTestes++; testesFalhados++;
        System.out.println("  [FAIL] " + nome + " -> " + motivo);
    }

    static void imprimirResumo(String modulo) {
        System.out.printf("  Resultado %s: %d/%d passaram | %d falharam%n%n",
                modulo, testesPassados, totalTestes, testesFalhados);
    }

    public static int getTestesFalhados() { return testesFalhados; }
}
