package atividade_10.test;

import atividade_10.controller.ClienteController;
import atividade_10.controller.PedidoController;
import atividade_10.controller.ProdutoController;
import atividade_10.exception.*;
import atividade_10.model.Pedido;
import atividade_10.model.StatusPedido;

import java.util.LinkedHashMap;
import java.util.Map;

public class PedidoTest {

    private static int totalTestes = 0;
    private static int testesPassados = 0;
    private static int testesFalhados = 0;


    private static ProdutoController prodCtrl;
    private static ClienteController cliCtrl;
    private static PedidoController pedCtrl;

    public static void executarTodos() {
        System.out.println("========== TESTES: Pedido ==========");
        configurarAmbiente();

        testeCriarPedidoValido();
        testeCriarPedidoClienteInexistente();
        testeCriarPedidoProdutoInexistente();
        testeCriarPedidoSemItens();
        testeReservarEstoqueComSucesso();
        testeReservarEstoqueInsuficiente();
        testeReservarEstoqueStatusInvalido();
        testePagarPedidoAprovado();
        testePagarPedidoRecusado();
        testePagarPedidoStatusInvalido();
        testeCancelarPedidoCriado();
        testeCancelarPedidoReservado_DevolvEstoque();
        testeCancelarPedidoPagoDeveLancarErro();
        testeDescontoMaiorQueTotal();
        testeFaturamentoTotal();
        testeTop3Produtos();
        testeFaturamentoPorCategoria();
        testeClientesComMaisPedidos();
        testeBuscarPedidoInexistente();

        imprimirResumo("Pedido");
    }

    private static void configurarAmbiente() {
        prodCtrl = new ProdutoController();
        cliCtrl  = new ClienteController();
        pedCtrl  = new PedidoController(prodCtrl, cliCtrl);

        try {
            prodCtrl.adicionarProduto("PROD-A", "Notebook", "Informatica", 3000.0, 10);
            prodCtrl.adicionarProduto("PROD-B", "Mouse",    "Perifericos",  150.0, 5);
            prodCtrl.adicionarProduto("PROD-C", "Teclado",  "Perifericos",  250.0, 0);

            cliCtrl.adicionarCliente("CLI-01", "Joao", "joao@test.com");
            cliCtrl.adicionarCliente("CLI-02", "Maria", "maria@test.com");
        } catch (DadosInvalidosException e) {
            System.out.println("[SETUP ERRO] " + e.getMessage());
        }
    }

    private static void testeCriarPedidoValido() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-A", 2);
            itens.put("PROD-B", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            assertTrue("Pedido criado com status CREATED", p.getStatus() == StatusPedido.CREATED);
            assertTrue("Pedido tem 2 tipos de itens", p.getItens().size() == 2);
            assertTrue("Total correto", p.getTotalBruto() == 6150.0);
            pass("testeCriarPedidoValido");
        } catch (Exception e) {
            fail("testeCriarPedidoValido", e.getMessage());
        }
    }

    private static void testeCriarPedidoClienteInexistente() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-A", 1);
            pedCtrl.criarPedido("CLI-999", itens);
            fail("testeCriarPedidoClienteInexistente", "Deveria ter lancado ClienteNaoEncontradoException");
        } catch (ClienteNaoEncontradoException e) {
            pass("testeCriarPedidoClienteInexistente");
        } catch (Exception e) {
            fail("testeCriarPedidoClienteInexistente", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeCriarPedidoProdutoInexistente() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("SKU-INVALIDO", 1);
            pedCtrl.criarPedido("CLI-01", itens);
            fail("testeCriarPedidoProdutoInexistente", "Deveria ter lancado ProdutoNaoEncontradoException");
        } catch (ProdutoNaoEncontradoException e) {
            pass("testeCriarPedidoProdutoInexistente");
        } catch (Exception e) {
            fail("testeCriarPedidoProdutoInexistente", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeCriarPedidoSemItens() {
        try {
            pedCtrl.criarPedido("CLI-01", new LinkedHashMap<>());
            fail("testeCriarPedidoSemItens", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeCriarPedidoSemItens");
        } catch (Exception e) {
            fail("testeCriarPedidoSemItens", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeReservarEstoqueComSucesso() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-A", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            String id = p.getPedidoId();

            int estoqueBefore = prodCtrl.buscarPorSku("PROD-A").getEstoque();
            pedCtrl.reservarEstoque(id);
            int estoqueAfter = prodCtrl.buscarPorSku("PROD-A").getEstoque();

            assertTrue("Status mudou para RESERVED", p.getStatus() == StatusPedido.RESERVED);
            assertTrue("Estoque foi debitado em 1", estoqueAfter == estoqueBefore - 1);
            pass("testeReservarEstoqueComSucesso");
        } catch (Exception e) {
            fail("testeReservarEstoqueComSucesso", e.getMessage());
        }
    }

    private static void testeReservarEstoqueInsuficiente() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-C", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            pedCtrl.reservarEstoque(p.getPedidoId());
            fail("testeReservarEstoqueInsuficiente", "Deveria ter lancado EstoqueInsuficienteException");
        } catch (EstoqueInsuficienteException e) {
            pass("testeReservarEstoqueInsuficiente");
        } catch (Exception e) {
            fail("testeReservarEstoqueInsuficiente", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeReservarEstoqueStatusInvalido() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-B", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            pedCtrl.reservarEstoque(p.getPedidoId());

            pedCtrl.reservarEstoque(p.getPedidoId());
            fail("testeReservarEstoqueStatusInvalido", "Deveria ter lancado StatusPedidoInvalidoException");
        } catch (StatusPedidoInvalidoException e) {
            pass("testeReservarEstoqueStatusInvalido");
        } catch (Exception e) {
            fail("testeReservarEstoqueStatusInvalido", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testePagarPedidoAprovado() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-A", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            pedCtrl.reservarEstoque(p.getPedidoId());
            pedCtrl.pagarPedido(p.getPedidoId(), 0.0, true);
            assertTrue("Status mudou para PAID", p.getStatus() == StatusPedido.PAID);
            pass("testePagarPedidoAprovado");
        } catch (Exception e) {
            fail("testePagarPedidoAprovado", e.getMessage());
        }
    }

    private static void testePagarPedidoRecusado() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-A", 1);
            Pedido p = pedCtrl.criarPedido("CLI-02", itens);
            pedCtrl.reservarEstoque(p.getPedidoId());
            pedCtrl.pagarPedido(p.getPedidoId(), 0.0, false);
            assertTrue("Status mudou para FAILED", p.getStatus() == StatusPedido.FAILED);
            pass("testePagarPedidoRecusado");
        } catch (Exception e) {
            fail("testePagarPedidoRecusado", e.getMessage());
        }
    }

    private static void testePagarPedidoStatusInvalido() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-B", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);

            pedCtrl.pagarPedido(p.getPedidoId(), 0.0, true);
            fail("testePagarPedidoStatusInvalido", "Deveria ter lancado StatusPedidoInvalidoException");
        } catch (StatusPedidoInvalidoException e) {
            pass("testePagarPedidoStatusInvalido");
        } catch (Exception e) {
            fail("testePagarPedidoStatusInvalido", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeCancelarPedidoCriado() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-A", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            pedCtrl.cancelarPedido(p.getPedidoId());
            assertTrue("Status mudou para CANCELLED", p.getStatus() == StatusPedido.CANCELLED);
            pass("testeCancelarPedidoCriado");
        } catch (Exception e) {
            fail("testeCancelarPedidoCriado", e.getMessage());
        }
    }

    private static void testeCancelarPedidoReservado_DevolvEstoque() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-A", 2);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            int estoqueBefore = prodCtrl.buscarPorSku("PROD-A").getEstoque();
            pedCtrl.reservarEstoque(p.getPedidoId());
            pedCtrl.cancelarPedido(p.getPedidoId());
            int estoqueAfter = prodCtrl.buscarPorSku("PROD-A").getEstoque();
            assertTrue("Estoque devolvido ao cancelar", estoqueAfter == estoqueBefore);
            assertTrue("Status CANCELLED", p.getStatus() == StatusPedido.CANCELLED);
            pass("testeCancelarPedidoReservado_DevolvEstoque");
        } catch (Exception e) {
            fail("testeCancelarPedidoReservado_DevolvEstoque", e.getMessage());
        }
    }

    private static void testeCancelarPedidoPagoDeveLancarErro() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-B", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            pedCtrl.reservarEstoque(p.getPedidoId());
            pedCtrl.pagarPedido(p.getPedidoId(), 0.0, true);
            pedCtrl.cancelarPedido(p.getPedidoId());
            fail("testeCancelarPedidoPagoDeveLancarErro", "Deveria ter lancado StatusPedidoInvalidoException");
        } catch (StatusPedidoInvalidoException e) {
            pass("testeCancelarPedidoPagoDeveLancarErro");
        } catch (Exception e) {
            fail("testeCancelarPedidoPagoDeveLancarErro", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeDescontoMaiorQueTotal() {
        try {
            Map<String, Integer> itens = new LinkedHashMap<>();
            itens.put("PROD-B", 1);
            Pedido p = pedCtrl.criarPedido("CLI-01", itens);
            pedCtrl.reservarEstoque(p.getPedidoId());
            pedCtrl.pagarPedido(p.getPedidoId(), 999.0, true);
            fail("testeDescontoMaiorQueTotal", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeDescontoMaiorQueTotal");
        } catch (Exception e) {
            fail("testeDescontoMaiorQueTotal", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeFaturamentoTotal() {
        try {
            double faturamento = pedCtrl.getFaturamentoTotal();
            assertTrue("Faturamento total e >= 0", faturamento >= 0);
            pass("testeFaturamentoTotal");
        } catch (Exception e) {
            fail("testeFaturamentoTotal", e.getMessage());
        }
    }

    private static void testeTop3Produtos() {
        try {
            var top3 = pedCtrl.getTop3ProdutosMaisVendidos();
            assertTrue("Top3 retorna ate 3 itens", top3.size() <= 3);
            pass("testeTop3Produtos");
        } catch (Exception e) {
            fail("testeTop3Produtos", e.getMessage());
        }
    }

    private static void testeFaturamentoPorCategoria() {
        try {
            var mapa = pedCtrl.getFaturamentoPorCategoria();
            assertTrue("Mapa de categorias nao e nulo", mapa != null);
            pass("testeFaturamentoPorCategoria");
        } catch (Exception e) {
            fail("testeFaturamentoPorCategoria", e.getMessage());
        }
    }

    private static void testeClientesComMaisPedidos() {
        try {
            var lista = pedCtrl.getClientesComMaisPedidos();
            assertTrue("Lista de clientes nao e nula", lista != null);
            pass("testeClientesComMaisPedidos");
        } catch (Exception e) {
            fail("testeClientesComMaisPedidos", e.getMessage());
        }
    }

    private static void testeBuscarPedidoInexistente() {
        try {
            pedCtrl.buscarPorId("PED-9999");
            fail("testeBuscarPedidoInexistente", "Deveria ter lancado PedidoNaoEncontradoException");
        } catch (PedidoNaoEncontradoException e) {
            pass("testeBuscarPedidoInexistente");
        } catch (Exception e) {
            fail("testeBuscarPedidoInexistente", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }



    private static void assertTrue(String descricao, boolean condicao) {
        if (!condicao) throw new AssertionError("Falhou: " + descricao);
    }

    private static void pass(String nome) {
        totalTestes++; testesPassados++;
        System.out.println("  [PASS] " + nome);
    }

    private static void fail(String nome, String motivo) {
        totalTestes++; testesFalhados++;
        System.out.println("  [FAIL] " + nome + " -> " + motivo);
    }

    static void imprimirResumo(String modulo) {
        System.out.printf("  Resultado %s: %d/%d passaram | %d falharam%n%n",
                modulo, testesPassados, totalTestes, testesFalhados);
    }

    public static int getTestesFalhados() { return testesFalhados; }
}
