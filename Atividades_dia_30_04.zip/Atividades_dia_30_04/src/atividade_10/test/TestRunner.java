package atividade_10.test;

public class TestRunner {

    public static void main(String[] args) {
        System.out.println("############################################");
        System.out.println("#    SUITE DE TESTES - ATIVIDADE 10       #");
        System.out.println("#    Simulador de Processamento de Pedidos #");
        System.out.println("############################################\n");


        ProdutoTest.executarTodos();
        ClienteTest.executarTodos();
        PedidoTest.executarTodos();


        int totalFalhas = ProdutoTest.getTestesFalhados()
                        + ClienteTest.getTestesFalhados()
                        + PedidoTest.getTestesFalhados();

        System.out.println("############################################");
        if (totalFalhas == 0) {
            System.out.println("  RESULTADO FINAL: TODOS OS TESTES PASSARAM!");
        } else {
            System.out.println("  RESULTADO FINAL: " + totalFalhas + " TESTE(S) FALHARAM!");
        }
        System.out.println("############################################");
    }
}
