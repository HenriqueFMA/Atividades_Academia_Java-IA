package atividade_10.test;

import atividade_10.controller.ProdutoController;
import atividade_10.exception.DadosInvalidosException;
import atividade_10.exception.ProdutoNaoEncontradoException;
import atividade_10.model.Produto;

public class ProdutoTest {

    private static int totalTestes = 0;
    private static int testesPassados = 0;
    private static int testesFalhados = 0;

    public static void executarTodos() {
        System.out.println("\n========== TESTES: Produto ==========");

        testeCriarProdutoValido();
        testeGetters();
        testeSkuNulo();
        testeSkuVazio();
        testeNomeNulo();
        testeCategoriaVazia();
        testePrecoNegativo();
        testeEstoqueNegativo();
        testeBuscarProdutoExistente();
        testeBuscarProdutoInexistente();
        testeSkuDuplicado();
        testeListarPorSku();
        testeListarPorPreco();
        testeSetterPrecoValido();
        testeSetterEstoqueValido();

        imprimirResumo("Produto");
    }



    private static void testeCriarProdutoValido() {
        try {
            Produto p = new Produto("SKU001", "Notebook Dell", "Informatica", 3500.00, 10);
            assertTrue("SKU normalizado para maiusculo", p.getSku().equals("SKU001"));
            assertTrue("Nome correto", p.getNome().equals("Notebook Dell"));
            assertTrue("Categoria correta", p.getCategoria().equals("Informatica"));
            assertTrue("Preco correto", p.getPreco() == 3500.00);
            assertTrue("Estoque correto", p.getEstoque() == 10);
            pass("testeCriarProdutoValido");
        } catch (Exception e) {
            fail("testeCriarProdutoValido", e.getMessage());
        }
    }

    private static void testeGetters() {
        try {
            Produto p = new Produto("sku-002", "Mouse Logitech", "Perifericos", 150.0, 50);
            assertTrue("SKU em maiusculo via getter", p.getSku().equals("SKU-002"));
            assertTrue("Nome via getter", p.getNome().equals("Mouse Logitech"));
            assertTrue("Categoria via getter", p.getCategoria().equals("Perifericos"));
            assertTrue("Preco via getter", p.getPreco() == 150.0);
            assertTrue("Estoque via getter", p.getEstoque() == 50);
            pass("testeGetters");
        } catch (Exception e) {
            fail("testeGetters", e.getMessage());
        }
    }

    private static void testeSkuNulo() {
        try {
            new Produto(null, "Produto X", "Cat", 10.0, 5);
            fail("testeSkuNulo", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeSkuNulo");
        } catch (Exception e) {
            fail("testeSkuNulo", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeSkuVazio() {
        try {
            new Produto("   ", "Produto X", "Cat", 10.0, 5);
            fail("testeSkuVazio", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeSkuVazio");
        } catch (Exception e) {
            fail("testeSkuVazio", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeNomeNulo() {
        try {
            new Produto("SKU003", null, "Cat", 10.0, 5);
            fail("testeNomeNulo", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeNomeNulo");
        } catch (Exception e) {
            fail("testeNomeNulo", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeCategoriaVazia() {
        try {
            new Produto("SKU004", "Produto", "", 10.0, 5);
            fail("testeCategoriaVazia", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeCategoriaVazia");
        } catch (Exception e) {
            fail("testeCategoriaVazia", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testePrecoNegativo() {
        try {
            new Produto("SKU005", "Produto", "Cat", -1.0, 5);
            fail("testePrecoNegativo", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testePrecoNegativo");
        } catch (Exception e) {
            fail("testePrecoNegativo", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeEstoqueNegativo() {
        try {
            new Produto("SKU006", "Produto", "Cat", 10.0, -5);
            fail("testeEstoqueNegativo", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeEstoqueNegativo");
        } catch (Exception e) {
            fail("testeEstoqueNegativo", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeBuscarProdutoExistente() {
        try {
            ProdutoController ctrl = new ProdutoController();
            ctrl.adicionarProduto("SKU010", "Teclado Mecânico", "Perifericos", 350.0, 20);
            Produto p = ctrl.buscarPorSku("SKU010");
            assertTrue("Produto encontrado corretamente", p.getSku().equals("SKU010"));
            pass("testeBuscarProdutoExistente");
        } catch (Exception e) {
            fail("testeBuscarProdutoExistente", e.getMessage());
        }
    }

    private static void testeBuscarProdutoInexistente() {
        try {
            ProdutoController ctrl = new ProdutoController();
            ctrl.buscarPorSku("INEXISTENTE");
            fail("testeBuscarProdutoInexistente", "Deveria ter lancado ProdutoNaoEncontradoException");
        } catch (ProdutoNaoEncontradoException e) {
            pass("testeBuscarProdutoInexistente");
        } catch (Exception e) {
            fail("testeBuscarProdutoInexistente", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeSkuDuplicado() {
        try {
            ProdutoController ctrl = new ProdutoController();
            ctrl.adicionarProduto("SKU020", "Produto A", "Cat", 10.0, 5);
            ctrl.adicionarProduto("SKU020", "Produto B", "Cat", 20.0, 3);
            fail("testeSkuDuplicado", "Deveria ter lancado DadosInvalidosException");
        } catch (DadosInvalidosException e) {
            pass("testeSkuDuplicado");
        } catch (Exception e) {
            fail("testeSkuDuplicado", "Excecao errada: " + e.getClass().getSimpleName());
        }
    }

    private static void testeListarPorSku() {
        try {
            ProdutoController ctrl = new ProdutoController();
            ctrl.adicionarProduto("C001", "Produto C", "Cat", 30.0, 5);
            ctrl.adicionarProduto("A001", "Produto A", "Cat", 10.0, 5);
            ctrl.adicionarProduto("B001", "Produto B", "Cat", 20.0, 5);
            var lista = ctrl.listarPorSku();
            assertTrue("Primeiro por SKU e A001", lista.get(0).getSku().equals("A001"));
            assertTrue("Terceiro por SKU e C001", lista.get(2).getSku().equals("C001"));
            pass("testeListarPorSku");
        } catch (Exception e) {
            fail("testeListarPorSku", e.getMessage());
        }
    }

    private static void testeListarPorPreco() {
        try {
            ProdutoController ctrl = new ProdutoController();
            ctrl.adicionarProduto("P001", "Barato", "Cat", 5.0, 5);
            ctrl.adicionarProduto("P002", "Caro", "Cat", 999.0, 5);
            ctrl.adicionarProduto("P003", "Medio", "Cat", 50.0, 5);
            var lista = ctrl.listarPorPreco();
            assertTrue("Primeiro por preco e o mais barato", lista.get(0).getPreco() == 5.0);
            assertTrue("Ultimo por preco e o mais caro", lista.get(2).getPreco() == 999.0);
            pass("testeListarPorPreco");
        } catch (Exception e) {
            fail("testeListarPorPreco", e.getMessage());
        }
    }

    private static void testeSetterPrecoValido() {
        try {
            Produto p = new Produto("SKU030", "Produto", "Cat", 100.0, 10);
            p.setPreco(200.0);
            assertTrue("Preco atualizado via setter", p.getPreco() == 200.0);
            pass("testeSetterPrecoValido");
        } catch (Exception e) {
            fail("testeSetterPrecoValido", e.getMessage());
        }
    }

    private static void testeSetterEstoqueValido() {
        try {
            Produto p = new Produto("SKU031", "Produto", "Cat", 100.0, 10);
            p.setEstoque(50);
            assertTrue("Estoque atualizado via setter", p.getEstoque() == 50);
            pass("testeSetterEstoqueValido");
        } catch (Exception e) {
            fail("testeSetterEstoqueValido", e.getMessage());
        }
    }



    private static void assertTrue(String descricao, boolean condicao) {
        if (!condicao) {
            throw new AssertionError("Falhou: " + descricao);
        }
    }

    private static void pass(String nome) {
        totalTestes++;
        testesPassados++;
        System.out.println("  [PASS] " + nome);
    }

    private static void fail(String nome, String motivo) {
        totalTestes++;
        testesFalhados++;
        System.out.println("  [FAIL] " + nome + " -> " + motivo);
    }

    static void imprimirResumo(String modulo) {
        System.out.printf("  Resultado %s: %d/%d passaram | %d falharam%n%n",
                modulo, testesPassados, totalTestes, testesFalhados);
    }

    public static int getTestesFalhados() { return testesFalhados; }
}
