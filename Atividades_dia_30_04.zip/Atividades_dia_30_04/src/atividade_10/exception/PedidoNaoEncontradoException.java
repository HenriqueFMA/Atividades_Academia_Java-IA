package atividade_10.exception;

public class PedidoNaoEncontradoException extends Exception {

    private static final long serialVersionUID = 1L;

    public PedidoNaoEncontradoException(String pedidoId) {
        super("Pedido com ID '" + pedidoId + "' nao encontrado.");
    }
}
