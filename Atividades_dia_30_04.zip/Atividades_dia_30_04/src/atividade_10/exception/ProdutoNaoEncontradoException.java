package atividade_10.exception;

public class ProdutoNaoEncontradoException extends Exception {

    private static final long serialVersionUID = 1L;

    public ProdutoNaoEncontradoException(String sku) {
        super("Produto com SKU '" + sku + "' nao encontrado.");
    }
}
