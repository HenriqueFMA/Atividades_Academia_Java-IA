package atividade_10.exception;

public class ClienteNaoEncontradoException extends Exception {

    private static final long serialVersionUID = 1L;

    public ClienteNaoEncontradoException(String customerId) {
        super("Cliente com ID '" + customerId + "' nao encontrado.");
    }
}
