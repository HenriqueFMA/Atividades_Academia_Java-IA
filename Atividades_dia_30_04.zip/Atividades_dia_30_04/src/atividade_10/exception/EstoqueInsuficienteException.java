package atividade_10.exception;

public class EstoqueInsuficienteException extends Exception {

    private static final long serialVersionUID = 1L;

    public EstoqueInsuficienteException(String sku, int solicitado, int disponivel) {
        super("Estoque insuficiente para o produto '" + sku + "'. Solicitado: "
                + solicitado + ", Disponivel: " + disponivel + ".");
    }
}
