package atividade_10.exception;

public class StatusPedidoInvalidoException extends Exception {

    private static final long serialVersionUID = 1L;

    public StatusPedidoInvalidoException(String operacao, String statusAtual) {
        super("Operacao '" + operacao + "' invalida para pedido com status '" + statusAtual + "'.");
    }
}
