package atividade_6;

public class Carro {

    private String marca;
    private String codigoCor;
    private double preco;
    private boolean ligado;
    private boolean emMovimento;

    public Carro(String marca, String codigoCor, double preco) {
        this.marca = marca;
        this.codigoCor = codigoCor;
        this.preco = preco;
        this.ligado = false;
        this.emMovimento = false;
    }

    public void exibir() {
        System.out.println("============================");
        System.out.println("         DADOS DO CARRO     ");
        System.out.println("============================");
        System.out.printf("  Marca      : %s%n", marca);
        System.out.printf("  Código Cor : %s%n", codigoCor);
        System.out.printf("  Preço      : R$ %.2f%n", preco);
        System.out.printf("  Ligado     : %s%n", ligado ? "Sim" : "Não");
        System.out.printf("  Movimento  : %s%n", emMovimento ? "Sim" : "Não");
        System.out.println("============================");
    }

    public void ligar() {
        if (ligado) {
            System.out.println("O carro já está ligado.");
        } else {
            ligado = true;
            System.out.println("Carro ligado!");
        }
    }

    public void desligar() {
        if (!ligado) {
            System.out.println("O carro já está desligado.");
        } else if (emMovimento) {
            System.out.println("Pare o carro antes de desligar.");
        } else {
            ligado = false;
            System.out.println("Carro desligado!");
        }
    }

    public void buzinar() {
        if (emMovimento) {
            System.out.println("Emitir som: Biiiii!");
        } else {
            System.out.println("O carro só buzina se estiver em movimento.");
        }
    }

    public void movimentar() {
        if (!ligado) {
            System.out.println("O carro só anda se estiver ligado.");
        } else if (emMovimento) {
            System.out.println("O carro já está em movimento.");
        } else {
            emMovimento = true;
            System.out.println("Carro em movimento!");
        }
    }

    public void parar() {
        if (emMovimento) {
            emMovimento = false;
            System.out.println("Carro parou.");
        } else {
            System.out.println("O carro já está parado.");
        }
    }
}