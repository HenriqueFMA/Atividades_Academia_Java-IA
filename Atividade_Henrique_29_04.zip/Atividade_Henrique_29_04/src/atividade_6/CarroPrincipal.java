package atividade_6;

import java.util.Scanner;

public class CarroPrincipal {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Carro carro = criarCarro();
        executarMenu(carro);
        scanner.close();
    }

    private static Carro criarCarro() {
        System.out.println("============================");
        System.out.println("     CADASTRO DO CARRO      ");
        System.out.println("============================");
        System.out.print("  Marca      : ");
        String marca = scanner.nextLine();
        System.out.print("  Código Cor : ");
        String codigoCor = scanner.nextLine();
        System.out.print("  Preço      : R$ ");
        double preco = scanner.nextDouble();
        scanner.nextLine();
        return new Carro(marca, codigoCor, preco);
    }

    private static void executarMenu(Carro carro) {
        int opcao;
        do {
            exibirMenu();
            opcao = scanner.nextInt();
            processarOpcao(carro, opcao);
        } while (opcao != 0);
    }

    private static void exibirMenu() {
        System.out.println("\n============================");
        System.out.println("          MENU CARRO        ");
        System.out.println("============================");
        System.out.println("  1 -> Exibir dados");
        System.out.println("  2 -> Ligar");
        System.out.println("  3 -> Desligar");
        System.out.println("  4 -> Movimentar");
        System.out.println("  5 -> Parar");
        System.out.println("  6 -> Buzinar");
        System.out.println("  0 -> Sair");
        System.out.println("============================");
        System.out.print("  Escolha: ");
    }

    private static void processarOpcao(Carro carro, int opcao) {
        System.out.println();
        if (opcao == 1) {
            carro.exibir();
        } else if (opcao == 2) {
            carro.ligar();
        } else if (opcao == 3) {
            carro.desligar();
        } else if (opcao == 4) {
            carro.movimentar();
        } else if (opcao == 5) {
            carro.parar();
        } else if (opcao == 6) {
            carro.buzinar();
        } else if (opcao == 0) {
            System.out.println("Encerrando sistema. Até logo!");
        } else {
            System.out.println("Opção inválida. Tente novamente.");
        }
    }
}