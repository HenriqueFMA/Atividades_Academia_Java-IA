package teste;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class TesteGeral {

    // ══════════════════════════════════════════════════════════════
    //  INFRA DE TESTES
    // ══════════════════════════════════════════════════════════════

    static int totalTestes = 0;
    static int totalPassou  = 0;
    static int totalFalhou  = 0;
    static List<String> falhas = new ArrayList<>();

    static void secao(String titulo) {
        System.out.println("\n╔══════════════════════════════════════════════════╗");
        System.out.printf ("║  %-48s║%n", titulo);
        System.out.println("╚══════════════════════════════════════════════════╝");
    }

    static void ok(String descricao) {
        totalTestes++;
        totalPassou++;
        System.out.println("  ✓  " + descricao);
    }

    static void falhou(String descricao, String esperado, String obtido) {
        totalTestes++;
        totalFalhou++;
        String msg = "  ✗  " + descricao
                   + "\n       Esperado : " + esperado
                   + "\n       Obtido   : " + obtido;
        System.out.println(msg);
        falhas.add(descricao);
    }

    static void verificar(String descricao, Object esperado, Object obtido) {
        boolean igual = (esperado == null && obtido == null)
                     || (esperado != null && esperado.equals(obtido));
        if (igual) ok(descricao);
        else       falhou(descricao, String.valueOf(esperado), String.valueOf(obtido));
    }

    static void verificarDouble(String descricao, double esperado, double obtido) {
        if (Math.abs(esperado - obtido) < 0.001) ok(descricao);
        else falhou(descricao, String.valueOf(esperado), String.valueOf(obtido));
    }

    static void verificarTrue(String descricao, boolean condicao) {
        if (condicao) ok(descricao);
        else          falhou(descricao, "true", "false");
    }

    static void resumo() {
        System.out.println("\n══════════════════════════════════════════════════════");
        System.out.printf("  RESULTADO FINAL: %d testes | ✓ %d passaram | ✗ %d falharam%n",
                totalTestes, totalPassou, totalFalhou);
        if (!falhas.isEmpty()) {
            System.out.println("\n  Testes que falharam:");
            for (String f : falhas) System.out.println("    • " + f);
        } else {
            System.out.println("\n  Todos os testes passaram! \\o/");
        }
        System.out.println("══════════════════════════════════════════════════════");
    }

    // ══════════════════════════════════════════════════════════════
    //  MAIN
    // ══════════════════════════════════════════════════════════════

    public static void main(String[] args) {
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println("  TESTADOR GERAL — Atividades Henrique 27/04");
        System.out.println("══════════════════════════════════════════════════════");

        testarAtividade1();
        testarAtividade2();
        testarAtividade3_NumToWords();
        testarAtividade3_NumerosInteiros();
        testarAtividade3_Eleicao();
        testarAtividade4();
        testarAtividade5();
        testarAtividade6();
        testarAtividade7();

        resumo();
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 1 — Ingressos
    // ══════════════════════════════════════════════════════════════

    static final double PRECO_A = 50.0;
    static final double PRECO_B = 30.0;
    static final double PRECO_C = 20.0;

    static double calcularValor(int qtd, double preco) {
        return qtd * preco;
    }

    static double somarTotal(double a, double b, double c) {
        return a + b + c;
    }

    static void testarAtividade1() {
        secao("Atividade 1 — Ingressos");

        // Teste 1: valores normais
        double a = calcularValor(2, PRECO_A);
        double b = calcularValor(3, PRECO_B);
        double c = calcularValor(5, PRECO_C);
        double total = somarTotal(a, b, c);
        verificarDouble("Classe A (2 ingressos × R$50)", 100.0, a);
        verificarDouble("Classe B (3 ingressos × R$30)", 90.0, b);
        verificarDouble("Classe C (5 ingressos × R$20)", 100.0, c);
        verificarDouble("Total arrecadado (2A+3B+5C = R$290)", 290.0, total);

        // Teste 2: zeros
        verificarDouble("Total com 0 ingressos de cada classe", 0.0,
                somarTotal(calcularValor(0, PRECO_A), calcularValor(0, PRECO_B), calcularValor(0, PRECO_C)));

        // Teste 3: apenas uma classe
        verificarDouble("Apenas 10 ingressos Classe A = R$500", 500.0, calcularValor(10, PRECO_A));

        // Teste 4: total grande
        verificarDouble("10A + 10B + 10C = R$1000", 1000.0,
                somarTotal(calcularValor(10, PRECO_A), calcularValor(10, PRECO_B), calcularValor(10, PRECO_C)));
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 2 — Calculadora
    // ══════════════════════════════════════════════════════════════

    static double calcular(double a, double b, int opcao) {
        switch (opcao) {
            case 1: return a + b;
            case 2: return a - b;
            case 3: return a * b;
            case 4: return b != 0 ? a / b : Double.NaN;
            default: return Double.NaN;
        }
    }

    static void testarAtividade2() {
        secao("Atividade 2 — Calculadora");

        verificarDouble("Soma: 10 + 5 = 15",           15.0, calcular(10, 5, 1));
        verificarDouble("Subtração: 10 - 3 = 7",         7.0, calcular(10, 3, 2));
        verificarDouble("Multiplicação: 4 × 5 = 20",    20.0, calcular(4, 5, 3));
        verificarDouble("Divisão: 20 ÷ 4 = 5",           5.0, calcular(20, 4, 4));
        verificarTrue  ("Divisão por zero retorna NaN",  Double.isNaN(calcular(10, 0, 4)));
        verificarDouble("Soma com negativos: -3 + 7 = 4", 4.0, calcular(-3, 7, 1));
        verificarDouble("Divisão decimal: 10 ÷ 3 ≈ 3.333", 10.0/3.0, calcular(10, 3, 4));
        verificarTrue  ("Opção inválida (99) retorna NaN", Double.isNaN(calcular(1, 1, 99)));
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 3a — NumToWords
    // ══════════════════════════════════════════════════════════════

    static final String[] NUMEROS = {
        "", "ONE", "TWO", "THREE", "FOUR",
        "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN"
    };

    static String converterNumero(int i) {
        if (i >= 1 && i <= 10) return NUMEROS[i];
        return "NUMBER " + i;
    }

    static void testarAtividade3_NumToWords() {
        secao("Atividade 3a — NumToWords");

        verificar("Número 1  → ONE",   "ONE",      converterNumero(1));
        verificar("Número 5  → FIVE",  "FIVE",     converterNumero(5));
        verificar("Número 10 → TEN",   "TEN",      converterNumero(10));
        verificar("Número 0  → NUMBER 0 (fora do range)",  "NUMBER 0",  converterNumero(0));
        verificar("Número 11 → NUMBER 11 (fora do range)", "NUMBER 11", converterNumero(11));
        verificar("Número -1 → NUMBER -1 (negativo)",      "NUMBER -1", converterNumero(-1));
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 3b — NumerosInteiros (filtrar pares)
    // ══════════════════════════════════════════════════════════════

    static ArrayList<Integer> filtrarPares(int[] numeros) {
        ArrayList<Integer> pares = new ArrayList<>();
        for (int n : numeros) if (n % 2 == 0) pares.add(n);
        return pares;
    }

    static void testarAtividade3_NumerosInteiros() {
        secao("Atividade 3b — NumerosInteiros (filtrar pares)");

        ArrayList<Integer> r1 = filtrarPares(new int[]{1, 2, 3, 4, 5});
        verificar("Pares de [1,2,3,4,5] = [2,4]", "[2, 4]", r1.toString());

        ArrayList<Integer> r2 = filtrarPares(new int[]{1, 3, 5, 7});
        verificar("Todos ímpares [1,3,5,7] = []", "[]", r2.toString());

        ArrayList<Integer> r3 = filtrarPares(new int[]{2, 4, 6});
        verificar("Todos pares [2,4,6] = [2,4,6]", "[2, 4, 6]", r3.toString());

        ArrayList<Integer> r4 = filtrarPares(new int[]{0, -2, -1, 3});
        verificar("Com zero e negativos [0,-2,-1,3]: pares = [0,-2]", "[0, -2]", r4.toString());

        ArrayList<Integer> r5 = filtrarPares(new int[]{});
        verificar("Array vazio → lista vazia", "[]", r5.toString());
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 3c — Eleição (lógica de votação)
    // ══════════════════════════════════════════════════════════════

    static int[] simularEleicao(int[] sequenciaVotos) {
        // [0]=A, [1]=B, [2]=brancos, [3]=nulos
        int[] votos = new int[4];
        int contadorB = 0;
        for (int voto : sequenciaVotos) {
            if (voto == 1) {
                votos[0]++;
            } else if (voto == 2) {
                contadorB++;
                if (contadorB % 3 == 0) votos[3]++;
                else                    votos[1]++;
            } else if (voto == 3) {
                votos[2]++;
            } else if (voto != 0) {
                votos[3]++;
            }
        }
        return votos;
    }

    static void testarAtividade3_Eleicao() {
        secao("Atividade 3c — Eleição");

        // 2×A, 2×B, 1×B(anulado pois é o 3º), 1×branco  → A=2 B=2 Br=1 Nu=1
        int[] r1 = simularEleicao(new int[]{1, 1, 2, 2, 2, 3});
        verificar("2A + 3B (3º anulado) + 1branco → candidato A = 2", 2, r1[0]);
        verificar("2A + 3B (3º anulado) + 1branco → candidato B = 2", 2, r1[1]);
        verificar("2A + 3B (3º anulado) + 1branco → brancos = 1",     1, r1[2]);
        verificar("2A + 3B (3º anulado) + 1branco → nulos = 1",       1, r1[3]);

        // Voto inválido (ex: 9)
        int[] r2 = simularEleicao(new int[]{9});
        verificar("Voto inválido (9) → nulos = 1", 1, r2[3]);

        // 6×B → o 3º e o 6º são anulados → B=4, nulos=2
        int[] r3 = simularEleicao(new int[]{2, 2, 2, 2, 2, 2});
        verificar("6 votos em B → B=4 (3º e 6º anulados)", 4, r3[1]);
        verificar("6 votos em B → nulos=2",                 2, r3[3]);

        // Nenhum voto
        int[] r4 = simularEleicao(new int[]{});
        verificar("Sem votos → total = 0", 0, r4[0] + r4[1] + r4[2] + r4[3]);
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 4 — LocalizaNumero
    // ══════════════════════════════════════════════════════════════

    static ArrayList<Integer> buscarNumero(int[] vetor, int numero) {
        ArrayList<Integer> posicoes = new ArrayList<>();
        for (int i = 0; i < vetor.length; i++)
            if (vetor[i] == numero) posicoes.add(i);
        return posicoes;
    }

    static void testarAtividade4() {
        secao("Atividade 4 — LocalizaNumero");

        int[] padrao = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        ArrayList<Integer> r1 = buscarNumero(padrao, 5);
        verificar("Vetor padrão, busca 5 → posição [4]", "[4]", r1.toString());

        ArrayList<Integer> r2 = buscarNumero(padrao, 11);
        verificar("Vetor padrão, busca 11 → não encontrado []", "[]", r2.toString());

        ArrayList<Integer> r3 = buscarNumero(new int[]{3, 7, 3, 9, 3}, 3);
        verificar("Busca 3 em [3,7,3,9,3] → posições [0,2,4]", "[0, 2, 4]", r3.toString());

        ArrayList<Integer> r4 = buscarNumero(new int[]{}, 1);
        verificar("Vetor vazio → não encontrado []", "[]", r4.toString());

        ArrayList<Integer> r5 = buscarNumero(new int[]{5, 5, 5}, 5);
        verificar("Todos iguais [5,5,5], busca 5 → [0,1,2]", "[0, 1, 2]", r5.toString());
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 5 — Animais (herança e polimorfismo)
    // ══════════════════════════════════════════════════════════════

    static class Animal5 {
        protected String nome;
        protected int    idade;
        Animal5(String nome, int idade) { this.nome = nome; this.idade = idade; }
        String emitirSom() { return nome + " emite um som."; }
        String exibir()    { return "Nome: " + nome + ", Idade: " + idade; }
    }

    static class Gato5 extends Animal5 {
        Gato5(String nome, int idade) { super(nome, idade); }
        @Override String emitirSom() { return nome + " faz: Miau!"; }
    }

    static class Dog5 extends Animal5 {
        Dog5(String nome, int idade) { super(nome, idade); }
        @Override String emitirSom() { return nome + " faz: Auau!"; }
    }

    static void testarAtividade5() {
        secao("Atividade 5 — Animais (herança/polimorfismo)");

        Gato5 gato = new Gato5("Mimi", 3);
        Dog5  dog  = new Dog5("Rex", 5);

        verificar("Gato emite som correto",  "Mimi faz: Miau!", gato.emitirSom());
        verificar("Dog emite som correto",   "Rex faz: Auau!",  dog.emitirSom());
        verificar("Gato exibe nome correto", "Nome: Mimi, Idade: 3", gato.exibir());
        verificar("Dog exibe nome correto",  "Nome: Rex, Idade: 5",  dog.exibir());

        // Polimorfismo via referência Animal5
        Animal5 a1 = new Gato5("Luna", 2);
        Animal5 a2 = new Dog5("Thor", 4);
        verificar("Polimorfismo: Animal → Gato → Miau", "Luna faz: Miau!", a1.emitirSom());
        verificar("Polimorfismo: Animal → Dog  → Auau", "Thor faz: Auau!",  a2.emitirSom());

        // Herança: campo nome acessível na subclasse
        verificarTrue("Nome do gato acessível via herança", gato.nome.equals("Mimi"));
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 6 — Carro (encapsulamento e estados)
    // ══════════════════════════════════════════════════════════════

    static class Carro6 {
        private boolean ligado      = false;
        private boolean emMovimento = false;

        String ligar() {
            if (ligado) return "O carro já está ligado.";
            ligado = true; return "Carro ligado!";
        }
        String desligar() {
            if (!ligado)     return "O carro já está desligado.";
            if (emMovimento) return "Pare o carro antes de desligar.";
            ligado = false;  return "Carro desligado!";
        }
        String movimentar() {
            if (!ligado)    return "O carro só anda se estiver ligado.";
            if (emMovimento) return "O carro já está em movimento.";
            emMovimento = true; return "Carro em movimento!";
        }
        String parar() {
            if (!emMovimento) return "O carro já está parado.";
            emMovimento = false; return "Carro parou.";
        }
        String buzinar() {
            return emMovimento ? "Emitir som: Biiiii!" : "O carro só buzina se estiver em movimento.";
        }
        boolean isLigado()      { return ligado; }
        boolean isEmMovimento() { return emMovimento; }
    }

    static void testarAtividade6() {
        secao("Atividade 6 — Carro (encapsulamento)");

        Carro6 c = new Carro6();

        verificar("Carro começa desligado", false, c.isLigado());
        verificar("Ligar carro", "Carro ligado!", c.ligar());
        verificar("Ligar novamente → já está ligado", "O carro já está ligado.", c.ligar());
        verificar("Buzinar parado → bloqueado", "O carro só buzina se estiver em movimento.", c.buzinar());
        verificar("Movimentar", "Carro em movimento!", c.movimentar());
        verificar("Movimentar de novo → já em movimento", "O carro já está em movimento.", c.movimentar());
        verificar("Buzinar em movimento", "Emitir som: Biiiii!", c.buzinar());
        verificar("Desligar em movimento → bloqueado", "Pare o carro antes de desligar.", c.desligar());
        verificar("Parar", "Carro parou.", c.parar());
        verificar("Parar de novo → já parado", "O carro já está parado.", c.parar());
        verificar("Desligar após parar", "Carro desligado!", c.desligar());
        verificar("Desligar de novo → já desligado", "O carro já está desligado.", c.desligar());
        verificar("Movimentar com carro desligado → bloqueado", "O carro só anda se estiver ligado.", c.movimentar());
    }

    // ══════════════════════════════════════════════════════════════
    //  ATIVIDADE 7 — João, Casa, Carro, Árvore
    // ══════════════════════════════════════════════════════════════

    static class Casa7 {
        private boolean ocupada = false;
        private String  morador = null;
        boolean isOcupada()         { return ocupada; }
        String  getMorador()        { return morador; }
        boolean receberMorador(String nome) {
            if (ocupada) return false;
            ocupada = true; morador = nome; return true;
        }
        boolean liberarCasa() {
            if (!ocupada) return false;
            morador = null; ocupada = false; return true;
        }
    }

    static class Carro7 {
        private boolean ligado      = false;
        private boolean emMovimento = false;
        private String  motorista   = null;
        boolean temMotorista()  { return motorista != null; }
        boolean isLigado()      { return ligado; }
        boolean isEmMovimento() { return emMovimento; }
        boolean receberMotorista(String nome) {
            if (motorista != null) return false;
            motorista = nome; return true;
        }
        boolean ejetarMotorista() {
            if (emMovimento || motorista == null) return false;
            motorista = null; return true;
        }
        boolean ligar()    { if (motorista==null||ligado) return false; ligado=true; return true; }
        boolean desligar() { if (!ligado||emMovimento)    return false; ligado=false; return true; }
        boolean dirigir()  { if (motorista==null||!ligado||emMovimento) return false; emMovimento=true; return true; }
        boolean parar()    { if (!emMovimento) return false; emMovimento=false; return true; }
    }

    static class Arvore7 {
        private int     idade;
        private boolean podada = false;
        Arvore7(int idade) { this.idade = idade; }
        boolean isPodada() { return podada; }
        int     getIdade() { return idade; }
        boolean serPodada() {
            if (podada) return false;
            podada = true; return true;
        }
        void crescer() { idade++; podada = false; }
    }

    static class Joao7 {
        private boolean emCasa  = false;
        private boolean noCarro = false;
        boolean isEmCasa()  { return emCasa; }
        boolean isNoCarro() { return noCarro; }

        boolean morarEm(Casa7 casa) {
            if (noCarro || emCasa) return false;
            if (casa.receberMorador("João")) { emCasa = true; return true; }
            return false;
        }
        boolean sairDaCasa(Casa7 casa) {
            if (!emCasa) return false;
            if (casa.liberarCasa()) { emCasa = false; return true; }
            return false;
        }
        boolean entrarNoCarro(Carro7 c) {
            if (emCasa || noCarro) return false;
            if (c.receberMotorista("João")) { noCarro = true; return true; }
            return false;
        }
        boolean sairDoCarro(Carro7 c) {
            if (!noCarro) return false;
            if (c.ejetarMotorista()) { noCarro = false; return true; }
            return false;
        }
        boolean ligarCarro(Carro7 c)   { return noCarro && c.ligar(); }
        boolean dirigirCarro(Carro7 c) { return noCarro && c.dirigir(); }
        boolean pararCarro(Carro7 c)   { return noCarro && c.parar(); }
        boolean desligarCarro(Carro7 c){ return noCarro && c.desligar(); }
        boolean podarArvore(Arvore7 a) { return !noCarro && a.serPodada(); }
    }

    static void testarAtividade7() {
        secao("Atividade 7 — João, Casa, Carro, Árvore");

        // ── Casa
        Joao7  joao  = new Joao7();
        Casa7  casa  = new Casa7();
        Carro7 carro = new Carro7();
        Arvore7 arv  = new Arvore7(5);

        verificarTrue("João entra na casa",         joao.morarEm(casa));
        verificarTrue("Casa está ocupada",          casa.isOcupada());
        verificarTrue("João está em casa",          joao.isEmCasa());
        verificarTrue("Não pode entrar no carro em casa", !joao.entrarNoCarro(carro));
        verificarTrue("João sai da casa",           joao.sairDaCasa(casa));
        verificarTrue("Casa está vazia",            !casa.isOcupada());

        // ── Carro
        verificarTrue("João entra no carro",        joao.entrarNoCarro(carro));
        verificarTrue("Carro tem motorista",        carro.temMotorista());
        verificarTrue("Não pode entrar na casa no carro", !joao.morarEm(casa));
        verificarTrue("Liga o carro",               joao.ligarCarro(carro));
        verificarTrue("Dirige o carro",             joao.dirigirCarro(carro));
        verificarTrue("Não pode sair em movimento", !joao.sairDoCarro(carro));
        verificarTrue("Para o carro",               joao.pararCarro(carro));
        verificarTrue("Desliga o carro",            joao.desligarCarro(carro));
        verificarTrue("João sai do carro",          joao.sairDoCarro(carro));

        // ── Árvore
        verificarTrue("João poda a árvore",         joao.podarArvore(arv));
        verificarTrue("Árvore está podada",         arv.isPodada());
        verificarTrue("Não pode podar de novo",     !joao.podarArvore(arv));
        arv.crescer();
        verificarTrue("Após crescer, podada = false", !arv.isPodada());
        verificar    ("Idade da árvore após crescer = 6", 6, arv.getIdade());
    }
}