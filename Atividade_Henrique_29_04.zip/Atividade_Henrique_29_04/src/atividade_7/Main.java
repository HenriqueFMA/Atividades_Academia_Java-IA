package atividade_7;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Joao   joao   = criarJoao();
        Casa   casa   = criarCasa();
        Carro  carro  = criarCarro();
        Arvore arvore = criarArvore();

        executarMenu(joao, casa, carro, arvore);
        scanner.close();
    }

    // ── Criação dos objetos ──────────────────────────────────────

    private static Joao criarJoao() {
        System.out.println("\n==== CADASTRO DO MORADOR ====");
        System.out.print("Nome: ");
        return new Joao(scanner.nextLine().trim());
    }

    private static Casa criarCasa() {
        System.out.println("\n==== CADASTRO DA CASA ====");
        System.out.print("Endereço: ");
        return new Casa(scanner.nextLine().trim());
    }

    private static Carro criarCarro() {
        System.out.println("\n==== CADASTRO DO CARRO ====");
        System.out.print("Modelo: ");
        return new Carro(scanner.nextLine().trim());
    }

    private static Arvore criarArvore() {
        System.out.println("\n==== CADASTRO DA ÁRVORE ====");
        System.out.print("Espécie : ");
        String especie = scanner.nextLine().trim();
        System.out.print("Idade   : ");
        int idade = lerInteiroSeguro();
        return new Arvore(especie, idade);
    }

    // ── Menu principal ───────────────────────────────────────────

    private static void executarMenu(Joao joao, Casa casa, Carro carro, Arvore arvore) {
        int opcao;
        do {
            exibirMenu();
            opcao = lerInteiroSeguro();
            System.out.println();
            processarOpcao(opcao, joao, casa, carro, arvore);
        } while (opcao != 0);
    }

    private static void exibirMenu() {
        System.out.println("\n============================");
        System.out.println("            MENU            ");
        System.out.println("============================");
        System.out.println("  [JOÃO]");
        System.out.println("   1  -> Ver dados de João");
        System.out.println("  [CASA]");
        System.out.println("   2  -> João entra na casa");
        System.out.println("   3  -> João sai da casa");
        System.out.println("   4  -> Ver dados da casa");
        System.out.println("  [CARRO]");
        System.out.println("   5  -> João entra no carro");
        System.out.println("   6  -> João sai do carro");
        System.out.println("   7  -> Ligar carro");
        System.out.println("   8  -> Dirigir carro");
        System.out.println("   9  -> Parar carro");
        System.out.println("   10 -> Desligar carro");
        System.out.println("   11 -> Ver dados do carro");
        System.out.println("  [ÁRVORE]");
        System.out.println("   12 -> Plantar árvore");
        System.out.println("   13 -> João poda a árvore");
        System.out.println("   14 -> Árvore cresce");
        System.out.println("   15 -> Ver dados da árvore");
        System.out.println("   0  -> Sair");
        System.out.println("============================");
        System.out.print("  Escolha: ");
    }

    private static void processarOpcao(int opcao, Joao joao, Casa casa, Carro carro, Arvore arvore) {
        switch (opcao) {
            case 1:  System.out.println(joao);                  break;
            case 2:  joao.morarEm(casa);                        break;
            case 3:  joao.sairDaCasa(casa);                     break;
            case 4:  System.out.println(casa);                  break;
            case 5:  joao.entrarNoCarro(carro);                 break;
            case 6:  joao.sairDoCarro(carro);                   break;
            case 7:  joao.ligarCarro(carro);                    break;
            case 8:  joao.dirigirCarro(carro);                  break;
            case 9:  joao.pararCarro(carro);                    break;
            case 10: joao.desligarCarro(carro);                 break;
            case 11: System.out.println(carro);                 break;
            case 12: plantarArvore(arvore);                     break;
            case 13: joao.podarArvore(arvore);                  break;
            case 14: arvore.crescer();                          break;
            case 15: System.out.println(arvore);                break;
            case 0:  System.out.println("Encerrando. Até logo!"); break;
            default: System.out.println("Opção inválida.");
        }
    }

    private static void plantarArvore(Arvore arvore) {
        System.out.print("Local para plantar: ");
        arvore.serPlantada(scanner.nextLine().trim());
    }

    // ── Utilitário ───────────────────────────────────────────────

    private static int lerInteiroSeguro() {
        while (true) {
            try {
                int valor = scanner.nextInt();
                scanner.nextLine();
                return valor;
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.print("Entrada inválida. Digite um número: ");
            }
        }
    }
}