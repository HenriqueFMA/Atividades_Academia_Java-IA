package atividade_7;

public class Arvore {

    private String especie;
    private int idade;
    private boolean podada;

    public Arvore(String especie, int idade) {
        this.especie = especie;
        this.idade = idade;
        this.podada = false;
    }

    public void serPlantada(String local) {
        System.out.printf("Árvore %s plantada em: %s.%n", especie, local);
    }

    public boolean serPodada(String nomeJardinheiro) {
        if (podada) {
            System.out.println("A árvore já foi podada recentemente.");
            return false;
        }
        podada = true;
        System.out.printf("%s podou a árvore %s.%n", nomeJardinheiro, especie);
        return true;
    }

    public void crescer() {
        idade++;
        podada = false;
        System.out.printf("A árvore %s cresceu! Agora tem %d ano(s).%n", especie, idade);
    }

    @Override
    public String toString() {
        return String.format(
            "============================\n" +
            "        DADOS DA ÁRVORE     \n" +
            "============================\n" +
            "  Espécie : %s\n" +
            "  Idade   : %d ano(s)\n" +
            "  Podada  : %s\n" +
            "============================",
            especie, idade, podada ? "Sim" : "Não"
        );
    }
}