package atividade_7;

public class Casa {

    private String endereco;
    private boolean ocupada;
    private String moradorAtual;

    public Casa(String endereco) {
        this.endereco = endereco;
        this.ocupada = false;
        this.moradorAtual = null;
    }

    public boolean isOcupada() { return ocupada; }
    public String getMoradorAtual() { return moradorAtual; }

    public boolean receberMorador(String nomeMorador) {
        if (ocupada) {
            System.out.printf("A casa já está ocupada por %s.%n", moradorAtual);
            return false;
        }
        ocupada = true;
        moradorAtual = nomeMorador;
        System.out.printf("%s entrou na casa.%n", nomeMorador);
        return true;
    }

    public boolean liberarCasa() {
        if (!ocupada) {
            System.out.println("A casa já está vazia.");
            return false;
        }
        System.out.printf("%s saiu da casa.%n", moradorAtual);
        moradorAtual = null;
        ocupada = false;
        return true;
    }

    @Override
    public String toString() {
        return String.format(
            "============================\n" +
            "         DADOS DA CASA      \n" +
            "============================\n" +
            "  Endereço : %s\n" +
            "  Ocupada  : %s\n" +
            "  Morador  : %s\n" +
            "============================",
            endereco,
            ocupada ? "Sim" : "Não",
            moradorAtual != null ? moradorAtual : "Nenhum"
        );
    }
}