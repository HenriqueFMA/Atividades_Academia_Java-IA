package atividade_7;

public class Joao {

    private final String nome;
    private boolean emCasa;
    private boolean noCarro;

    public Joao(String nome) {
        this.nome = nome;
        this.emCasa = false;
        this.noCarro = false;
    }

    public String getNome() { return nome; }

    public void morarEm(Casa casa) {
        if (noCarro) { System.out.println("Saia do carro antes de entrar na casa."); return; }
        if (emCasa)  { System.out.println("Você já está na casa."); return; }
        if (casa.receberMorador(nome)) emCasa = true;
    }

    public void sairDaCasa(Casa casa) {
        if (!emCasa) { System.out.println("Você não está na casa."); return; }
        if (casa.liberarCasa()) emCasa = false;
    }

    public void entrarNoCarro(Carro carro) {
        if (emCasa)  { System.out.println("Saia da casa antes de entrar no carro."); return; }
        if (noCarro) { System.out.println("Você já está no carro."); return; }
        if (carro.receberMotorista(nome)) noCarro = true;
    }

    public void sairDoCarro(Carro carro) {
        if (!noCarro) { System.out.println("Você não está no carro."); return; }
        if (carro.ejetarMotorista()) noCarro = false;
    }

    public void ligarCarro(Carro carro) {
        if (!noCarro) { System.out.println("Entre no carro primeiro."); return; }
        carro.ligar();
    }

    public void dirigirCarro(Carro carro) {
        if (!noCarro) { System.out.println("Entre no carro primeiro."); return; }
        carro.dirigir();
    }

    public void pararCarro(Carro carro) {
        if (!noCarro) { System.out.println("Você não está no carro."); return; }
        carro.parar();
    }

    public void desligarCarro(Carro carro) {
        if (!noCarro) { System.out.println("Entre no carro primeiro."); return; }
        carro.desligar();
    }

    public void podarArvore(Arvore arvore) {
        if (noCarro) { System.out.println("Saia do carro antes de podar a árvore."); return; }
        arvore.serPodada(nome);
    }

    @Override
    public String toString() {
        return String.format(
            "============================\n" +
            "        DADOS DE JOÃO       \n" +
            "============================\n" +
            "  Nome     : %s\n" +
            "  Em casa  : %s\n" +
            "  No carro : %s\n" +
            "============================",
            nome,
            emCasa  ? "Sim" : "Não",
            noCarro ? "Sim" : "Não"
        );
    }
}