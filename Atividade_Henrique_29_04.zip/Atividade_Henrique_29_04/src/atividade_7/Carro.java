package atividade_7;

public class Carro {

    private String modelo;
    private boolean ligado;
    private boolean emMovimento;
    private String motorista;

    public Carro(String modelo) {
        this.modelo = modelo;
        this.ligado = false;
        this.emMovimento = false;
        this.motorista = null;
    }

    public boolean isLigado()      { return ligado; }
    public boolean isEmMovimento() { return emMovimento; }
    public boolean temMotorista()  { return motorista != null; }

    public boolean receberMotorista(String nome) {
        if (motorista != null) {
            System.out.printf("O carro já tem motorista: %s.%n", motorista);
            return false;
        }
        motorista = nome;
        System.out.printf("%s entrou no %s.%n", nome, modelo);
        return true;
    }

    public boolean ejetarMotorista() {
        if (emMovimento) {
            System.out.println("Impossível sair do carro em movimento.");
            return false;
        }
        if (motorista == null) {
            System.out.println("Não há motorista no carro.");
            return false;
        }
        System.out.printf("%s saiu do carro.%n", motorista);
        motorista = null;
        return true;
    }

    public boolean ligar() {
        if (motorista == null) { System.out.println("Ninguém no carro para ligá-lo."); return false; }
        if (ligado)            { System.out.println("O carro já está ligado."); return false; }
        ligado = true;
        System.out.printf("%s ligou o %s.%n", motorista, modelo);
        return true;
    }

    public boolean desligar() {
        if (!ligado)     { System.out.println("O carro já está desligado."); return false; }
        if (emMovimento) { System.out.println("Pare o carro antes de desligar."); return false; }
        ligado = false;
        System.out.printf("%s desligou o %s.%n", motorista, modelo);
        return true;
    }

    public boolean dirigir() {
        if (motorista == null) { System.out.println("Sem motorista para dirigir."); return false; }
        if (!ligado)           { System.out.println("Ligue o carro antes de dirigir."); return false; }
        if (emMovimento)       { System.out.println("O carro já está em movimento."); return false; }
        emMovimento = true;
        System.out.printf("%s está dirigindo o %s.%n", motorista, modelo);
        return true;
    }

    public boolean parar() {
        if (!emMovimento) { System.out.println("O carro já está parado."); return false; }
        emMovimento = false;
        System.out.printf("%s parou.%n", modelo);
        return true;
    }

    @Override
    public String toString() {
        return String.format(
            "============================\n" +
            "        DADOS DO CARRO      \n" +
            "============================\n" +
            "  Modelo    : %s\n" +
            "  Ligado    : %s\n" +
            "  Movimento : %s\n" +
            "  Motorista : %s\n" +
            "============================",
            modelo,
            ligado ? "Sim" : "Não",
            emMovimento ? "Sim" : "Não",
            motorista != null ? motorista : "Nenhum"
        );
    }
}