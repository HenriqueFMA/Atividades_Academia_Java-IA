package atividade_2;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean continuar = true;

        System.out.println("===== CALCULADORA JAVA =====");

        while (continuar) {

            double num1 = lerNumero(sc, "Digite o primeiro número: ");
            double num2 = lerNumero(sc, "Digite o segundo número: ");
            int opcao = lerOpcao(sc);

            double resultado = calcular(num1, num2, opcao);

            if (!Double.isNaN(resultado)) {
                System.out.println("Resultado: " + resultado);
            }

            continuar = desejaContinuar(sc);
        }

        System.out.println("Encerrando calculadora...");
        sc.close();
    }

    // ================= MÉTODOS =================

    public static double lerNumero(Scanner sc, String mensagem) {
        double numero;

        while (true) {
            System.out.print(mensagem);

            if (sc.hasNextDouble()) {
                numero = sc.nextDouble();
                return numero;
            } else {
                System.out.println("Entrada inválida! Digite um número.");
                sc.next(); // limpa entrada
            }
        }
    }

    public static int lerOpcao(Scanner sc) {
        System.out.println("\nEscolha a operação:");
        System.out.println("1 - Soma");
        System.out.println("2 - Subtração");
        System.out.println("3 - Multiplicação");
        System.out.println("4 - Divisão");

        while (true) {
            System.out.print("Opção: ");

            if (sc.hasNextInt()) {
                int opcao = sc.nextInt();

                if (opcao >= 1 && opcao <= 4) {
                    return opcao;
                }
            } else {
                sc.next();
            }

            System.out.println("Opção inválida! Tente novamente.");
        }
    }

    public static double calcular(double a, double b, int opcao) {

        switch (opcao) {
            case 1:
                return a + b;

            case 2:
                return a - b;

            case 3:
                return a * b;

            case 4:
                if (b != 0) {
                    return a / b;
                } else {
                    System.out.println("Erro: divisão por zero.");
                    return Double.NaN;
                }

            default:
                return Double.NaN;
        }
    }

    public static boolean desejaContinuar(Scanner sc) {
        System.out.print("\nDeseja continuar? (s/n): ");
        String resposta = sc.next().toLowerCase();
        return resposta.equals("s");
    }
}