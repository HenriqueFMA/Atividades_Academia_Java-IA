package atividade_5;

public class Dog extends Animal {

    public Dog(String nome, int idade) {
        super(nome, idade);
    }

    @Override
    public void emitirSom() {
        System.out.println(nome + " faz: Auau!");
    }
}