package atividade_5;

import java.util.Scanner;

public class PrincipalAnimais {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Gato gato = criarGato();
        Dog dog = criarDog();
        executarMenu(gato, dog);
        scanner.close();
    }

    private static Gato criarGato() {
        System.out.println("============================");
        System.out.println("       CADASTRO DO GATO     ");
        System.out.println("============================");
        System.out.print("  Nome  : ");
        String nome = scanner.nextLine();
        System.out.print("  Idade : ");
        int idade = scanner.nextInt();
        scanner.nextLine();
        return new Gato(nome, idade);
    }

    private static Dog criarDog() {
        System.out.println("\n============================");
        System.out.println("       CADASTRO DO DOG      ");
        System.out.println("============================");
        System.out.print("  Nome  : ");
        String nome = scanner.nextLine();
        System.out.print("  Idade : ");
        int idade = scanner.nextInt();
        scanner.nextLine();
        return new Dog(nome, idade);
    }

    private static void executarMenu(Gato gato, Dog dog) {
        int opcao;
        do {
            exibirMenu();
            opcao = scanner.nextInt();
            processarOpcao(gato, dog, opcao);
        } while (opcao != 0);
    }

    private static void exibirMenu() {
        System.out.println("\n============================");
        System.out.println("           MENU             ");
        System.out.println("============================");
        System.out.println("  1 -> Exibir dados do Gato");
        System.out.println("  2 -> Gato emitir som");
        System.out.println("  3 -> Exibir dados do Dog");
        System.out.println("  4 -> Dog emitir som");
        System.out.println("  5 -> Todos emitirem som");
        System.out.println("  0 -> Sair");
        System.out.println("============================");
        System.out.print("  Escolha: ");
    }

    private static void processarOpcao(Gato gato, Dog dog, int opcao) {
        System.out.println();
        if (opcao == 1) {
            gato.exibir();
        } else if (opcao == 2) {
            gato.emitirSom();
        } else if (opcao == 3) {
            dog.exibir();
        } else if (opcao == 4) {
            dog.emitirSom();
        } else if (opcao == 5) {
            gato.emitirSom();
            dog.emitirSom();
        } else if (opcao == 0) {
            System.out.println("Encerrando sistema. Até logo!");
        } else {
            System.out.println("Opção inválida. Tente novamente.");
        }
    }
}