package atividade_5;

public class Animal {

    protected String nome;
    protected int idade;

    public Animal(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public void emitirSom() {
        System.out.println(nome + " emite um som.");
    }

    public void exibir() {
        System.out.printf("  Nome  : %s%n", nome);
        System.out.printf("  Idade : %d ano(s)%n", idade);
    }
}