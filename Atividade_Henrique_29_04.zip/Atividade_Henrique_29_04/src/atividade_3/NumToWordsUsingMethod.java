package atividade_3;

import java.util.Scanner;

public class NumToWordsUsingMethod {

    private static final String[] NUMEROS = {
        "", "ONE", "TWO", "THREE", "FOUR",
        "FIVE", "SIX", "SEVEN", "EIGHT",
        "NINE", "TEN"
    };

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int numero = lerNumero(sc);

        String resultado = converterNumero(numero);

        exibirResultado(resultado);

        sc.close();
    }

    // ================= MÉTODOS =================

    public static int lerNumero(Scanner sc) {
        System.out.print("Digite um número: ");

        while (!sc.hasNextInt()) {
            System.out.print("Entrada inválida! Digite um número inteiro: ");
            sc.next();
        }

        return sc.nextInt();
    }

    public static String converterNumero(int i) {
        if (i >= 1 && i <= 10) {
            return NUMEROS[i];
        }
        return "NUMBER " + i;
    }

    public static void exibirResultado(String resultado) {
        System.out.println("Resultado: " + resultado);
    }
}