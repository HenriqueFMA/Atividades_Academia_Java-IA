package atividade_3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class NumerosInteiros2 {

    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int quantidade = lerQuantidade();
        int[] numeros = lerNumeros(quantidade);
        ArrayList<Integer> pares = filtrarPares(numeros);
        exibirResultados(numeros, pares);
        input.close();
    }

    private static int lerQuantidade() {
        System.out.print("\nQuantos números você deseja digitar: ");
        return input.nextInt();
    }

    private static int[] lerNumeros(int quantidade) {
        int[] numeros = new int[quantidade];
        for (int i = 0; i < numeros.length; i++) {
            System.out.printf("Entre com a posição %d: ", i + 1);
            numeros[i] = input.nextInt();
        }
        return numeros;
    }

    private static ArrayList<Integer> filtrarPares(int[] numeros) {
        ArrayList<Integer> pares = new ArrayList<>();
        for (int n : numeros) {
            if (n % 2 == 0) pares.add(n);
        }
        return pares;
    }

    private static void exibirResultados(int[] numeros, ArrayList<Integer> pares) {
        int qtdPares = pares.size();

        String labelNumeros = numeros.length == 1
                ? "O número digitado é: "
                : "Os números digitados são: ";

        String labelPares = qtdPares == 1
                ? "A quantidade de números pares é " + qtdPares + ".\n" + pares + " é um número par."
                : "Desses números apenas " + qtdPares + " são pares.\nOs números pares são: " + pares;

        System.out.println("\n" + labelNumeros + Arrays.toString(numeros));
        System.out.println(labelPares);
    }
}