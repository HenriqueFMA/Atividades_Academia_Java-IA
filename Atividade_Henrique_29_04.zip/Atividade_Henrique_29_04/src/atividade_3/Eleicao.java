package atividade_3;

import java.util.Scanner;

public class Eleicao {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int[] votos = coletarVotos();
        scanner.close();
        exibirResultados(votos);
    }

    private static int[] coletarVotos() {
        // [0] = candidatoA, [1] = candidatoB, [2] = brancos, [3] = nulos
        int[] votos = new int[4];
        int contadorVotosB = 0;

        while (true) {
            exibirMenu();
            int voto = lerVoto();

            if (voto == 0) {
                System.out.println("Votação encerrada!\n");
                break;
            } else if (voto == 1) {
                confirmarVoto("Candidato A");
                votos[0]++;
            } else if (voto == 2) {
                contadorVotosB++;
                if (contadorVotosB % 3 == 0) {
                    votos[3]++;
                    System.out.println("Terceiro voto no candidato B anulado!\n");
                    pausar(2000);
                } else {
                    confirmarVoto("Candidato B");
                    votos[1]++;
                }
            } else if (voto == 3) {
                confirmarVoto("Branco");
                votos[2]++;
            } else {
                System.out.println("Voto inválido! Seu voto foi anulado.");
                pausar(2000);
                votos[3]++;
            }
        }

        return votos;
    }

    private static void exibirMenu() {
        System.out.println("Escolha seu candidato ou tecle zero para encerrar\n");
        System.out.println("  1 -> Candidato A");
        System.out.println("  2 -> Candidato B");
        System.out.println("  3 -> Voto em Branco");
        System.out.println("  0 -> Encerrar votação");
        System.out.println("\nQualquer número diferente de 0, 1, 2 e 3 anulará o seu voto");
    }

    private static int lerVoto() {
        System.out.print("Digite seu voto: ");
        return scanner.nextInt();
    }

    private static void confirmarVoto(String opcao) {
        System.out.println("\nVoto registrado para: " + opcao);
        System.out.println("Confirmando");
        for (int i = 0; i < 3; i++) {
            pausar(500);
            System.out.print(".");
        }
        pausar(500);
        System.out.println(" OK!\n");
    }

    private static void pausar(int milissegundos) {
        try {
            Thread.sleep(milissegundos);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void exibirResultados(int[] votos) {
        int totalVotos = calcularTotal(votos);

        if (totalVotos == 0) {
            System.out.println("Nenhum voto registrado.");
            return;
        }

        System.out.printf("%nTotal de votos: %d%n%n", totalVotos);
        imprimirResultado("Candidato A",  votos[0], totalVotos);
        imprimirResultado("Candidato B",  votos[1], totalVotos);
        imprimirResultado("Voto em Branco", votos[2], totalVotos);
        imprimirResultado("Nulos",        votos[3], totalVotos);
    }

    private static int calcularTotal(int[] votos) {
        int total = 0;
        for (int v : votos) total += v;
        return total;
    }

    private static void imprimirResultado(String label, int qtd, int total) {
        double porcentagem = (qtd * 100.0) / total;
        System.out.printf("%-16s: %3d voto(s) | %6.2f%% do total%n",
                label, qtd, porcentagem);
    }
}