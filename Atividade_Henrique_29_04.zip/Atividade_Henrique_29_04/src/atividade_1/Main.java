package atividade_1;

import java.util.Scanner;

public class Main {

    static final double PRECO_A = 50.0;
    static final double PRECO_B = 30.0;
    static final double PRECO_C = 20.0;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int qtdA = lerQuantidade(sc, "Digite a quantidade de ingressos Classe A: ");
        int qtdB = lerQuantidade(sc, "Digite a quantidade de ingressos Classe B: ");
        int qtdC = lerQuantidade(sc, "Digite a quantidade de ingressos Classe C: ");

        double totalA = calcularValor(qtdA, PRECO_A);
        double totalB = calcularValor(qtdB, PRECO_B);
        double totalC = calcularValor(qtdC, PRECO_C);

        double totalGeral = somarTotal(totalA, totalB, totalC);

        exibirResultado(totalA, totalB, totalC, totalGeral);

        sc.close();
    }

    public static int lerQuantidade(Scanner sc, String mensagem) {
        System.out.print(mensagem);
        return sc.nextInt();
    }

    public static double calcularValor(int quantidade, double preco) {
        return quantidade * preco;
    }

    public static double somarTotal(double a, double b, double c) {
        return a + b + c;
    }

    public static void exibirResultado(double a, double b, double c, double total) {
        System.out.println("\n--- RESULTADO ---");
        System.out.println("Classe A: R$ " + a);
        System.out.println("Classe B: R$ " + b);
        System.out.println("Classe C: R$ " + c);
        System.out.println("Total arrecadado: R$ " + total);
    }
}