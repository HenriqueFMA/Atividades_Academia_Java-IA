package atividade_4;

import java.util.ArrayList;
import java.util.Scanner;

public class LocalizaNumero {

    private static final Scanner scanner = new Scanner(System.in);
    private static final int[] VETOR_PADRAO = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    public static void main(String[] args) {
        int[] vetor = escolherVetor();
        exibirVetor(vetor);
        int numero = lerNumero();
        ArrayList<Integer> posicoes = buscarNumero(vetor, numero);
        exibirResultado(numero, posicoes);
        scanner.close();
    }

    private static int[] escolherVetor() {
        System.out.println("============================");
        System.out.println("   LOCALIZADOR DE NÚMEROS   ");
        System.out.println("============================");
        System.out.println("\nComo deseja definir o vetor?");
        System.out.println("  1 -> Usar vetor padrão");
        System.out.println("  2 -> Preencher manualmente");
        System.out.print("\nEscolha: ");

        int opcao = scanner.nextInt();
        return opcao == 2 ? preencherVetor() : VETOR_PADRAO;
    }

    private static int[] preencherVetor() {
        System.out.print("\nQuantos números deseja inserir no vetor: ");
        int tamanho = scanner.nextInt();

        int[] vetor = new int[tamanho];
        for (int i = 0; i < vetor.length; i++) {
            System.out.printf("  Posição %d: ", i);
            vetor[i] = scanner.nextInt();
        }
        return vetor;
    }

    private static void exibirVetor(int[] vetor) {
        System.out.println("\nVetor:");
        for (int i = 0; i < vetor.length; i++) {
            System.out.printf("  Posição %d -> %d%n", i, vetor[i]);
        }
    }

    private static int lerNumero() {
        System.out.print("\nDigite o número a ser pesquisado: ");
        return scanner.nextInt();
    }

    private static ArrayList<Integer> buscarNumero(int[] vetor, int numero) {
        ArrayList<Integer> posicoes = new ArrayList<>();
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] == numero) posicoes.add(i);
        }
        return posicoes;
    }

    private static void exibirResultado(int numero, ArrayList<Integer> posicoes) {
        if (posicoes.isEmpty()) {
            System.out.printf("%nNúmero %d não encontrado no vetor.%n", numero);
            return;
        }

        String labelPosicao = posicoes.size() == 1 ? "posição" : "posições";
        System.out.printf("%nNúmero %d encontrado em %d %s:%n", numero, posicoes.size(), labelPosicao);
        for (int posicao : posicoes) {
            System.out.printf("  -> Posição %d%n", posicao);
        }
    }
}